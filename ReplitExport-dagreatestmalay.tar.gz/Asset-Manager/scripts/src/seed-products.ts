import { getUncachableStripeClient } from "./stripeClient";

async function createProducts() {
  try {
    const stripe = await getUncachableStripeClient();
    console.log("Checking for existing Sentinel Black Pro products...");

    const existing = await stripe.products.search({
      query: "name:'Sentinel Black Pro' AND active:'true'",
    });

    if (existing.data.length > 0) {
      console.log("Sentinel Black Pro already exists:", existing.data[0].id);
      const prices = await stripe.prices.list({ product: existing.data[0].id, active: true });
      for (const p of prices.data) {
        console.log(`  Price: ${p.id} — ${p.unit_amount! / 100} ${p.currency.toUpperCase()}/${(p.recurring as any)?.interval}`);
      }
      return;
    }

    console.log("Creating Sentinel Black Pro product...");
    const product = await stripe.products.create({
      name: "Sentinel Black Pro",
      description: "Full access to Sentinel Black intelligence console — unlimited cases, AI summaries, file storage, and priority support.",
      metadata: { tier: "pro" },
    });
    console.log("Created product:", product.id);

    const monthly = await stripe.prices.create({
      product: product.id,
      unit_amount: 2900,
      currency: "usd",
      recurring: { interval: "month" },
      metadata: { label: "Pro Monthly" },
    });
    console.log("Created monthly price:", monthly.id, "($29.00/mo)");

    const yearly = await stripe.prices.create({
      product: product.id,
      unit_amount: 29000,
      currency: "usd",
      recurring: { interval: "year" },
      metadata: { label: "Pro Annual" },
    });
    console.log("Created yearly price:", yearly.id, "($290.00/yr — save 17%)");

    console.log("\nProducts seeded successfully. Webhooks will sync to database.");
  } catch (err: any) {
    console.error("Error:", err.message);
    process.exit(1);
  }
}

createProducts();
