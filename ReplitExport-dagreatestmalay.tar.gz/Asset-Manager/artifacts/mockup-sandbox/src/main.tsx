import React from "react";
import ReactDOM from "react-dom/client";

const App: React.FC = () => {
  return (
    <>
      <style>{`
        :root {
          color-scheme: dark;
          --sb-bg: #050509;
          --sb-bg-elevated: #0b0b12;
          --sb-bg-soft: #11111b;
          --sb-accent: #e11d48;
          --sb-accent-soft: rgba(225, 29, 72, 0.16);
          --sb-accent-strong: rgba(225, 29, 72, 0.32);
          --sb-border-subtle: rgba(148, 163, 184, 0.18);
          --sb-text-main: #e5e7eb;
          --sb-text-soft: #9ca3af;
          --sb-text-faint: #6b7280;
          --sb-glow: 0 0 40px rgba(225, 29, 72, 0.35);
          --sb-radius-lg: 18px;
          --sb-radius-md: 12px;
          --sb-radius-pill: 999px;
        }

        * {
          box-sizing: border-box;
        }

        html, body, #root {
          margin: 0;
          padding: 0;
          height: 100%;
          width: 100%;
          font-family: system-ui, -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif;
          background: radial-gradient(circle at top, #111827 0, #020617 40%, #000 100%);
          color: var(--sb-text-main);
        }

        body {
          overflow: hidden;
        }

        .sb-root {
          height: 100vh;
          width: 100vw;
          display: flex;
          align-items: stretch;
          justify-content: center;
          padding: 18px;
          background:
            radial-gradient(circle at 10% 0%, rgba(248, 113, 113, 0.08) 0, transparent 45%),
            radial-gradient(circle at 90% 100%, rgba(59, 130, 246, 0.08) 0, transparent 45%),
            radial-gradient(circle at 50% 50%, rgba(15, 23, 42, 0.9) 0, #020617 70%);
        }

        .sb-shell {
          display: grid;
          grid-template-columns: 260px minmax(0, 1fr);
          grid-template-rows: minmax(0, 1fr);
          gap: 16px;
          width: 100%;
          max-width: 1240px;
          max-height: 720px;
          background: linear-gradient(135deg, rgba(15, 23, 42, 0.96), rgba(2, 6, 23, 0.98));
          border-radius: 26px;
          border: 1px solid rgba(148, 163, 184, 0.25);
          box-shadow:
            0 40px 120px rgba(15, 23, 42, 0.9),
            0 0 0 1px rgba(15, 23, 42, 0.9);
          overflow: hidden;
          position: relative;
        }

        .sb-shell::before {
          content: "";
          position: absolute;
          inset: 0;
          background:
            radial-gradient(circle at 0 0, rgba(248, 113, 113, 0.12) 0, transparent 45%),
            radial-gradient(circle at 100% 100%, rgba(59, 130, 246, 0.12) 0, transparent 45%);
          opacity: 0.6;
          pointer-events: none;
        }

        .sb-shell-inner {
          position: relative;
          display: contents;
          z-index: 1;
        }

        /* Sidebar */

        .sb-sidebar {
          background: radial-gradient(circle at 0 0, rgba(15, 23, 42, 0.9) 0, #020617 70%);
          border-right: 1px solid var(--sb-border-subtle);
          padding: 18px 16px;
          display: flex;
          flex-direction: column;
          gap: 18px;
        }

        .sb-logo-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
        }

        .sb-logo-mark {
          width: 32px;
          height: 32px;
          border-radius: 12px;
          background:
            radial-gradient(circle at 30% 0%, #f97373 0, transparent 55%),
            radial-gradient(circle at 70% 100%, #f97373 0, transparent 55%),
            radial-gradient(circle at 50% 50%, #020617 0, #020617 60%);
          border: 1px solid rgba(248, 113, 113, 0.7);
          box-shadow: var(--sb-glow);
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;
        }

        .sb-logo-eye {
          width: 16px;
          height: 16px;
          border-radius: 999px;
          border: 1px solid rgba(248, 250, 252, 0.7);
          display: flex;
          align-items: center;
          justify-content: center;
          background: radial-gradient(circle at 50% 30%, #f9fafb 0, #020617 80%);
        }

        .sb-logo-eye-dot {
          width: 6px;
          height: 6px;
          border-radius: 999px;
          background: #ef4444;
          box-shadow: 0 0 12px rgba(248, 113, 113, 0.9);
        }

        .sb-logo-text {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .sb-logo-title {
          font-size: 14px;
          letter-spacing: 0.16em;
          text-transform: uppercase;
          color: #f9fafb;
        }

        .sb-logo-sub {
          font-size: 11px;
          color: var(--sb-text-faint);
        }

        .sb-pill {
          padding: 4px 10px;
          border-radius: var(--sb-radius-pill);
          border: 1px solid rgba(148, 163, 184, 0.4);
          background: linear-gradient(135deg, rgba(15, 23, 42, 0.9), rgba(15, 23, 42, 0.4));
          font-size: 11px;
          color: var(--sb-text-soft);
          display: inline-flex;
          align-items: center;
          gap: 6px;
        }

        .sb-pill-dot {
          width: 7px;
          height: 7px;
          border-radius: 999px;
          background: #22c55e;
          box-shadow: 0 0 10px rgba(34, 197, 94, 0.9);
        }

        .sb-section-label {
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.16em;
          color: var(--sb-text-faint);
          margin-bottom: 4px;
        }

        .sb-nav {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .sb-nav-item {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 7px 9px;
          border-radius: 10px;
          font-size: 13px;
          color: var(--sb-text-soft);
          cursor: pointer;
          border: 1px solid transparent;
          transition: all 0.16s ease-out;
        }

        .sb-nav-item span {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .sb-nav-item-dot {
          width: 7px;
          height: 7px;
          border-radius: 999px;
          background: rgba(148, 163, 184, 0.7);
        }

        .sb-nav-item-active {
          background: radial-gradient(circle at 0 0, rgba(248, 113, 113, 0.18) 0, rgba(15, 23, 42, 0.9) 55%);
          border-color: rgba(248, 113, 113, 0.7);
          color: #f9fafb;
          box-shadow: var(--sb-glow);
        }

        .sb-nav-item-active .sb-nav-item-dot {
          background: #f97373;
          box-shadow: 0 0 10px rgba(248, 113, 113, 0.9);
        }

        .sb-nav-item:hover:not(.sb-nav-item-active) {
          background: rgba(15, 23, 42, 0.9);
          border-color: rgba(148, 163, 184, 0.4);
        }

        .sb-nav-kbd {
          font-size: 10px;
          padding: 2px 6px;
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.5);
          color: var(--sb-text-faint);
        }

        .sb-divider {
          height: 1px;
          border-radius: 999px;
          background: linear-gradient(
            90deg,
            transparent,
            rgba(148, 163, 184, 0.4),
            transparent
          );
          margin: 4px 0;
        }

        .sb-badge-row {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }

        .sb-badge {
          font-size: 11px;
          padding: 4px 8px;
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.4);
          color: var(--sb-text-soft);
          background: rgba(15, 23, 42, 0.9);
        }

        .sb-footer {
          margin-top: auto;
          display: flex;
          flex-direction: column;
          gap: 10px;
          font-size: 11px;
          color: var(--sb-text-faint);
        }

        .sb-footer-card {
          padding: 8px 9px;
          border-radius: 12px;
          border: 1px solid rgba(148, 163, 184, 0.4);
          background: radial-gradient(circle at 0 0, rgba(248, 113, 113, 0.16) 0, rgba(15, 23, 42, 0.96) 55%);
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .sb-footer-card-title {
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.16em;
          color: #f9fafb;
        }

        .sb-footer-card-pill-row {
          display: flex;
          gap: 6px;
          flex-wrap: wrap;
        }

        .sb-footer-card-pill {
          padding: 3px 7px;
          border-radius: 999px;
          border: 1px solid rgba(248, 113, 113, 0.7);
          font-size: 10px;
          color: #fecaca;
          background: rgba(127, 29, 29, 0.4);
        }

        .sb-footer-meta {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 8px;
        }

        .sb-footer-meta span {
          display: inline-flex;
          align-items: center;
          gap: 6px;
        }

        .sb-footer-meta-dot {
          width: 6px;
          height: 6px;
          border-radius: 999px;
          background: #f97373;
        }

        /* Main */

        .sb-main {
          padding: 18px 18px 18px 4px;
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .sb-main-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
        }

        .sb-main-title-block {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .sb-main-eyebrow {
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.16em;
          color: var(--sb-text-faint);
        }

        .sb-main-title {
          font-size: 20px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .sb-main-title-highlight {
          padding: 2px 8px;
          border-radius: 999px;
          border: 1px solid rgba(248, 113, 113, 0.7);
          background: rgba(127, 29, 29, 0.4);
          font-size: 11px;
          color: #fecaca;
        }

        .sb-main-sub {
          font-size: 12px;
          color: var(--sb-text-soft);
        }

        .sb-main-actions {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .sb-ghost-btn,
        .sb-primary-btn {
          border-radius: 999px;
          font-size: 12px;
          padding: 7px 12px;
          border: 1px solid rgba(148, 163, 184, 0.6);
          background: rgba(15, 23, 42, 0.9);
          color: var(--sb-text-main);
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          transition: all 0.16s ease-out;
        }

        .sb-ghost-btn:hover {
          border-color: rgba(148, 163, 184, 0.9);
          background: rgba(15, 23, 42, 1);
        }

        .sb-primary-btn {
          border-color: rgba(248, 113, 113, 0.9);
          background: radial-gradient(circle at 0 0, rgba(248, 113, 113, 0.3) 0, rgba(127, 29, 29, 0.9) 55%);
          box-shadow: var(--sb-glow);
        }

        .sb-primary-btn:hover {
          filter: brightness(1.05);
        }

        .sb-main-grid {
          display: grid;
          grid-template-columns: minmax(0, 1.4fr) minmax(0, 1fr);
          grid-template-rows: minmax(0, 1fr);
          gap: 12px;
          height: 100%;
        }

        .sb-panel {
          border-radius: var(--sb-radius-lg);
          border: 1px solid var(--sb-border-subtle);
          background: radial-gradient(circle at 0 0, rgba(15, 23, 42, 0.96) 0, #020617 70%);
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
          position: relative;
          overflow: hidden;
        }

        .sb-panel::before {
          content: "";
          position: absolute;
          inset: 0;
          background: radial-gradient(circle at 0 0, rgba(248, 113, 113, 0.12) 0, transparent 55%);
          opacity: 0.4;
          pointer-events: none;
        }

        .sb-panel-inner {
          position: relative;
          z-index: 1;
          display: flex;
          flex-direction: column;
          gap: 10px;
          height: 100%;
        }

        .sb-panel-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
        }

        .sb-panel-title {
          font-size: 13px;
          text-transform: uppercase;
          letter-spacing: 0.16em;
          color: var(--sb-text-soft);
        }

        .sb-panel-meta {
          font-size: 11px;
          color: var(--sb-text-faint);
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .sb-chip {
          padding: 2px 7px;
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.6);
          font-size: 10px;
          color: var(--sb-text-soft);
        }

        .sb-list {
          display: flex;
          flex-direction: column;
          gap: 6px;
          overflow: auto;
          padding-right: 4px;
        }

        .sb-list-item {
          border-radius: 12px;
          border: 1px solid rgba(31, 41, 55, 0.9);
          background: linear-gradient(135deg, rgba(15, 23, 42, 0.96), rgba(15, 23, 42, 0.7));
          padding: 8px 9px;
          display: flex;
          flex-direction: column;
          gap: 4px;
          cursor: pointer;
          transition: all 0.16s ease-out;
        }

        .sb-list-item:hover {
          border-color: rgba(248, 113, 113, 0.7);
          box-shadow: 0 0 0 1px rgba(248, 113, 113, 0.4);
        }

        .sb-list-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
        }

        .sb-list-title {
          font-size: 13px;
          color: #e5e7eb;
        }

        .sb-list-sub {
          font-size: 11px;
          color: var(--sb-text-soft);
        }

        .sb-tag-row {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }

        .sb-tag {
          font-size: 10px;
          padding: 3px 7px;
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.5);
          color: var(--sb-text-soft);
        }

        .sb-tag-critical {
          border-color: rgba(248, 113, 113, 0.9);
          color: #fecaca;
          background: rgba(127, 29, 29, 0.6);
        }

        .sb-timeline {
          display: flex;
          flex-direction: column;
          gap: 8px;
          overflow: auto;
          padding-right: 4px;
        }

        .sb-timeline-item {
          display: grid;
          grid-template-columns: auto 1fr;
          gap: 8px;
          font-size: 11px;
          color: var(--sb-text-soft);
        }

        .sb-timeline-time {
          color: var(--sb-text-faint);
          padding-top: 2px;
        }

        .sb-timeline-dot-col {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
        }

        .sb-timeline-dot {
          width: 8px;
          height: 8px;
          border-radius: 999px;
          background: rgba(148, 163, 184, 0.9);
        }

        .sb-timeline-dot-critical {
          background: #f97373;
          box-shadow: 0 0 10px rgba(248, 113, 113, 0.9);
        }

        .sb-timeline-line {
          flex: 1;
          width: 1px;
          background: linear-gradient(
            to bottom,
            rgba(148, 163, 184, 0.6),
            transparent
          );
        }

        .sb-timeline-card {
          border-radius: 10px;
          border: 1px solid rgba(31, 41, 55, 0.9);
          background: linear-gradient(135deg, rgba(15, 23, 42, 0.96), rgba(15, 23, 42, 0.7));
          padding: 6px 8px;
          display: flex;
          flex-direction: column;
          gap: 3px;
        }

        .sb-timeline-label {
          font-size: 11px;
          color: #e5e7eb;
        }

        .sb-timeline-meta {
          font-size: 10px;
          color: var(--sb-text-faint);
        }

        .sb-stats-row {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 8px;
        }

        .sb-stat-card {
          border-radius: 12px;
          border: 1px solid rgba(31, 41, 55, 0.9);
          background: radial-gradient(circle at 0 0, rgba(15, 23, 42, 0.96) 0, #020617 70%);
          padding: 8px 9px;
          display: flex;
          flex-direction: column;
          gap: 4px;
          font-size: 11px;
          color: var(--sb-text-soft);
        }

        .sb-stat-label {
          text-transform: uppercase;
          letter-spacing: 0.16em;
          font-size: 10px;
          color: var(--sb-text-faint);
        }

        .sb-stat-value {
          font-size: 16px;
          font-weight: 600;
          color: #f9fafb;
        }

        .sb-stat-pill {
          font-size: 10px;
          padding: 2px 6px;
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.6);
          color: var(--sb-text-soft);
          align-self: flex-start;
        }

        .sb-stat-pill-critical {
          border-color: rgba(248, 113, 113, 0.9);
          color: #fecaca;
        }

        .sb-quick-row {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }

        .sb-quick-btn {
          font-size: 11px;
          padding: 5px 9px;
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.6);
          background: rgba(15, 23, 42, 0.96);
          color: var(--sb-text-soft);
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          transition: all 0.16s ease-out;
        }

        .sb-quick-btn span {
          font-size: 12px;
        }

        .sb-quick-btn:hover {
          border-color: rgba(248, 113, 113, 0.9);
          color: #f9fafb;
        }

        .sb-quick-btn-danger {
          border-color: rgba(248, 113, 113, 0.9);
          color: #fecaca;
          background: rgba(127, 29, 29, 0.7);
        }

        .sb-ai-strip {
          margin-top: auto;
          border-radius: 12px;
          border: 1px dashed rgba(148, 163, 184, 0.6);
          background: radial-gradient(circle at 0 0, rgba(15, 23, 42, 0.96) 0, #020617 70%);
          padding: 7px 9px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          font-size: 11px;
          color: var(--sb-text-soft);
        }

        .sb-ai-strip span {
          display: inline-flex;
          align-items: center;
          gap: 6px;
        }

        .sb-ai-pill {
          padding: 3px 7px;
          border-radius: 999px;
          border: 1px solid rgba(248, 113, 113, 0.7);
          color: #fecaca;
          background: rgba(127, 29, 29, 0.6);
          font-size: 10px;
        }

        @media (max-width: 960px) {
          .sb-shell {
            grid-template-columns: 220px minmax(0, 1fr);
          }
        }

        @media (max-width: 820px) {
          .sb-shell {
            grid-template-columns: minmax(0, 1fr);
            grid-template-rows: auto minmax(0, 1fr);
          }
          .sb-sidebar {
            border-right: none;
            border-bottom: 1px solid var(--sb-border-subtle);
            flex-direction: row;
            align-items: center;
            overflow-x: auto;
          }
          .sb-footer {
            display: none;
          }
        }

        @media (max-width: 720px) {
          .sb-main-grid {
            grid-template-columns: minmax(0, 1fr);
            grid-template-rows: auto auto;
          }
        }
      `}</style>

      <div className="sb-root">
        <div className="sb-shell">
          <div className="sb-shell-inner">
            {/* Sidebar */}
            <aside className="sb-sidebar">
              <div className="sb-logo-row">
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div className="sb-logo-mark">
                    <div className="sb-logo-eye">
                      <div className="sb-logo-eye-dot" />
                    </div>
                  </div>
                  <div className="sb-logo-text">
                    <div className="sb-logo-title">Sentinel Black</div>
                    <div className="sb-logo-sub">
                      Forensic‑intelligence • Evidence Engine
                    </div>
                  </div>
                </div>
                <div className="sb-pill">
                  <span className="sb-pill-dot" />
                  Live shield
                </div>
              </div>

              <div>
                <div className="sb-section-label">Console</div>
                <div className="sb-nav">
                  <div className="sb-nav-item sb-nav-item-active">
                    <span>
                      <div className="sb-nav-item-dot" />
                      Dashboard
                    </span>
                    <div className="sb-nav-kbd">⌘1</div>
                  </div>
                  <div className="sb-nav-item">
                    <span>
                      <div className="sb-nav-item-dot" />
                      Evidence Vault
                    </span>
                    <div className="sb-nav-kbd">⌘2</div>
                  </div>
                  <div className="sb-nav-item">
                    <span>
                      <div className="sb-nav-item-dot" />
                      Pattern Map
                    </span>
                    <div className="sb-nav-kbd">⌘3</div>
                  </div>
                  <div className="sb-nav-item">
                    <span>
                      <div className="sb-nav-item-dot" />
                      Reports & Exports
                    </span>
                    <div className="sb-nav-kbd">⌘4</div>
                  </div>
                </div>
              </div>

              <div className="sb-divider" />

              <div>
                <div className="sb-section-label">Protection modes</div>
                <div className="sb-badge-row">
                  <div className="sb-badge">Black Mode • Armed</div>
                  <div className="sb-badge">Decoy Vault • Safe</div>
                  <div className="sb-badge">Identity‑safe logging</div>
                </div>
              </div>

              <div className="sb-footer">
                <div className="sb-footer-card">
                  <div className="sb-footer-card-title">Active case</div>
                  <div>Retaliation & escalation tracking is live.</div>
                  <div className="sb-footer-card-pill-row">
                    <div className="sb-footer-card-pill">
                      Chain‑of‑custody locked
                    </div>
                    <div className="sb-footer-card-pill">
                      Legal‑grade timeline
                    </div>
                  </div>
                </div>
                <div className="sb-footer-meta">
                  <span>
                    <div className="sb-footer-meta-dot" />
                    12 incidents mapped • 4 actors
                  </span>
                  <span>Export ready • PDF / JSON</span>
                </div>
              </div>
            </aside>

            {/* Main */}
            <main className="sb-main">
              <header className="sb-main-header">
                <div className="sb-main-title-block">
                  <div className="sb-main-eyebrow">Forensic dashboard</div>
                  <div className="sb-main-title">
                    Evidence Engine
                    <span className="sb-main-title-highlight">
                      Case: Workplace retaliation • Live
                    </span>
                  </div>
                  <div className="sb-main-sub">
                    Every log is timestamped, hashed, and chained. You’re not
                    “venting”—you’re building a legal‑grade record.
                  </div>
                </div>
                <div className="sb-main-actions">
                  <button className="sb-ghost-btn">
                    <span>⟳</span>
                    Sync sources
                  </button>
                  <button className="sb-primary-btn">
                    <span>＋</span>
                    New incident entry
                  </button>
                </div>
              </header>

              <section className="sb-main-grid">
                {/* Left panel: Evidence list */}
                <section className="sb-panel">
                  <div className="sb-panel-inner">
                    <div className="sb-panel-header">
                      <div>
                        <div className="sb-panel-title">Evidence vault</div>
                        <div className="sb-panel-meta">
                          <span>Last 30 entries</span>
                          <span>•</span>
                          <span>Sorted by escalation weight</span>
                        </div>
                      </div>
                      <div className="sb-panel-meta">
                        <div className="sb-chip">Encrypted at rest</div>
                        <div className="sb-chip">Zero‑knowledge mode</div>
                      </div>
                    </div>

                    <div className="sb-list">
                      <div className="sb-list-item">
                        <div className="sb-list-row">
                          <div className="sb-list-title">
                            Manager threatens schedule after HR complaint
                          </div>
                          <div className="sb-tag-row">
                            <div className="sb-tag sb-tag-critical">
                              Retaliation
                            </div>
                            <div className="sb-tag">Verbal • In‑person</div>
                            <div className="sb-tag">Audio note • 03:12</div>
                          </div>
                        </div>
                        <div className="sb-list-row">
                          <div className="sb-list-sub">
                            Logged: May 26, 2026 • 09:14 PM • Location pinned •
                            Witness flagged
                          </div>
                          <div className="sb-list-sub">
                            Chain ID: SB‑A9F3‑22C1
                          </div>
                        </div>
                      </div>

                      <div className="sb-list-item">
                        <div className="sb-list-row">
                          <div className="sb-list-title">
                            Shift removed after protected report
                          </div>
                          <div className="sb-tag-row">
                            <div className="sb-tag sb-tag-critical">
                              Adverse action
                            </div>
                            <div className="sb-tag">Schedule change</div>
                            <div className="sb-tag">Screenshot • Portal</div>
                          </div>
                        </div>
                        <div className="sb-list-row">
                          <div className="sb-list-sub">
                            Logged: May 24, 2026 • 02:37 PM • HR ticket linked
                          </div>
                          <div className="sb-list-sub">
                            Chain ID: SB‑7D42‑9B0E
                          </div>
                        </div>
                      </div>

                      <div className="sb-list-item">
                        <div className="sb-list-row">
                          <div className="sb-list-title">
                            Group chat mocking medical accommodation
                          </div>
                          <div className="sb-tag-row">
                            <div className="sb-tag sb-tag-critical">
                              Harassment
                            </div>
                            <div className="sb-tag">Digital • Chat</div>
                            <div className="sb-tag">Exported thread</div>
                          </div>
                        </div>
                        <div className="sb-list-row">
                          <div className="sb-list-sub">
                            Logged: May 21, 2026 • 11:02 PM • Participants
                            mapped
                          </div>
                          <div className="sb-list-sub">
                            Chain ID: SB‑C4E8‑11AF
                          </div>
                        </div>
                      </div>

                      <div className="sb-list-item">
                        <div className="sb-list-row">
                          <div className="sb-list-title">
                            HR acknowledges complaint but takes no action
                          </div>
                          <div className="sb-tag-row">
                            <div className="sb-tag">System failure</div>
                            <div className="sb-tag">Email • PDF</div>
                            <div className="sb-tag">Policy mismatch</div>
                          </div>
                        </div>
                        <div className="sb-list-row">
                          <div className="sb-list-sub">
                            Logged: May 18, 2026 • 04:19 PM • Policy attached
                          </div>
                          <div className="sb-list-sub">
                            Chain ID: SB‑3A77‑5C9D
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>

                {/* Right panel: Timeline + stats */}
                <section className="sb-panel">
                  <div className="sb-panel-inner">
                    <div className="sb-panel-header">
                      <div>
                        <div className="sb-panel-title">
                          Pattern & escalation map
                        </div>
                        <div className="sb-panel-meta">
                          Chronology of retaliation after protected activity
                        </div>
                      </div>
                      <div className="sb-panel-meta">
                        <div className="sb-chip">AI pattern detection • On</div>
                      </div>
                    </div>

                    <div className="sb-timeline">
                      <div className="sb-timeline-item">
                        <div className="sb-timeline-time">May 10</div>
                        <div className="sb-timeline-dot-col">
                          <div className="sb-timeline-dot" />
                          <div className="sb-timeline-line" />
                        </div>
                        <div className="sb-timeline-card">
                          <div className="sb-timeline-label">
                            Initial HR complaint filed (protected activity)
                          </div>
                          <div className="sb-timeline-meta">
                            Evidence: HR ticket • Email confirmation • Policy
                            reference
                          </div>
                        </div>
                      </div>

                      <div className="sb-timeline-item">
                        <div className="sb-timeline-time">May 14</div>
                        <div className="sb-timeline-dot-col">
                          <div className="sb-timeline-dot sb-timeline-dot-critical" />
                          <div className="sb-timeline-line" />
                        </div>
                        <div className="sb-timeline-card">
                          <div className="sb-timeline-label">
                            Schedule cut within 72 hours of complaint
                          </div>
                          <div className="sb-timeline-meta">
                            AI note: Timing + adverse action = high retaliation
                            signal
                          </div>
                        </div>
                      </div>

                      <div className="sb-timeline-item">
                        <div className="sb-timeline-time">May 18</div>
                        <div className="sb-timeline-dot-col">
                          <div className="sb-timeline-dot" />
                          <div className="sb-timeline-line" />
                        </div>
                        <div className="sb-timeline-card">
                          <div className="sb-timeline-label">
                            HR “no action” response despite evidence
                          </div>
                          <div className="sb-timeline-meta">
                            Pattern: institutional failure • supports hostile
                            environment claim
                          </div>
                        </div>
                      </div>

                      <div className="sb-timeline-item">
                        <div className="sb-timeline-time">May 21</div>
                        <div className="sb-timeline-dot-col">
                          <div className="sb-timeline-dot sb-timeline-dot-critical" />
                          <div className="sb-timeline-line" />
                        </div>
                        <div className="sb-timeline-card">
                          <div className="sb-timeline-label">
                            Group chat harassment about medical accommodation
                          </div>
                          <div className="sb-timeline-meta">
                            Actors linked: 3 supervisors • 2 peers • same chain
                            as schedule cut
                          </div>
                        </div>
                      </div>

                      <div className="sb-timeline-item">
                        <div className="sb-timeline-time">May 24</div>
                        <div className="sb-timeline-dot-col">
                          <div className="sb-timeline-dot sb-timeline-dot-critical" />
                          <div className="sb-timeline-line" />
                        </div>
                        <div className="sb-timeline-card">
                          <div className="sb-timeline-label">
                            Additional shift removed after follow‑up complaint
                          </div>
                          <div className="sb-timeline-meta">
                            Escalation tier: Critical • Retaliation pattern now
                            multi‑step
                          </div>
                        </div>
                      </div>

                      <div className="sb-timeline-item">
                        <div className="sb-timeline-time">May 26</div>
                        <div className="sb-timeline-dot-col">
                          <div className="sb-timeline-dot sb-timeline-dot-critical" />
                        </div>
                        <div className="sb-timeline-card">
                          <div className="sb-timeline-label">
                            Threat about “attitude” after raising rights
                          </div>
                          <div className="sb-timeline-meta">
                            Recommended: export full report for attorney /
                            agency filing
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="sb-stats-row">
                      <div className="sb-stat-card">
                        <div className="sb-stat-label">Incidents logged</div>
                        <div className="sb-stat-value">12</div>
                        <div className="sb-stat-pill">4 in last 7 days</div>
                      </div>
                      <div className="sb-stat-card">
                        <div className="sb-stat-label">Retaliation score</div>
                        <div className="sb-stat-value">92%</div>
                        <div className="sb-stat-pill sb-stat-pill-critical">
                          High • Pattern established
                        </div>
                      </div>
                      <div className="sb-stat-card">
                        <div className="sb-stat-label">Chain integrity</div>
                        <div className="sb-stat-value">100%</div>
                        <div className="sb-stat-pill">No edits • No gaps</div>
                      </div>
                    </div>

                    <div className="sb-quick-row">
                      <button className="sb-quick-btn">
                        <span>⬇</span>
                        Export legal‑ready report (PDF)
                      </button>
                      <button className="sb-quick-btn">
                        <span>⧉</span>
                        Copy incident summary
                      </button>
                      <button className="sb-quick-btn">
                        <span>⚑</span>
                        Mark key actors
                      </button>
                      <button className="sb-quick-btn sb-quick-btn-danger">
                        <span>🛡</span>
                        Arm Black Mode emergency kit
                      </button>
                    </div>

                    <div className="sb-ai-strip">
                      <span>
                        <span>◎</span>
                        AI note: “Your logs show a clear timeline of protected
                        activity followed by adverse actions. This is the
                        pattern attorneys look for.”
                      </span>
                      <span className="sb-ai-pill">Explain this pattern ▸</span>
                    </div>
                  </div>
                </section>
              </section>
            </main>
          </div>
        </div>
      </div>
    </>
  );
};

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
