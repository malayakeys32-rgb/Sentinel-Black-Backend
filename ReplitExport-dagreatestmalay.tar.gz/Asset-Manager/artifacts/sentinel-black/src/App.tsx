import { useEffect, useRef } from "react";
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { Switch, Route, useLocation, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Dashboard from "@/pages/dashboard";
import Cases from "@/pages/cases";
import CaseDetails from "@/pages/case-details";
import Billing from "@/pages/billing";
import Layout from "@/components/layout";

const queryClient = new QueryClient();

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY in .env file");
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/sentinel-logo.png`,
  },
  variables: {
    colorPrimary: "#dc2626",
    colorForeground: "hsl(0, 0%, 96%)",
    colorMutedForeground: "hsl(0, 0%, 45%)",
    colorDanger: "hsl(0, 84%, 60%)",
    colorBackground: "#0f0f0f",
    colorInput: "#1a1a1a",
    colorInputForeground: "hsl(0, 0%, 96%)",
    colorNeutral: "#1a1a1a",
    fontFamily: "'Space Mono', 'Menlo', 'Monaco', 'Courier New', monospace",
    borderRadius: "0px",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "rounded-none w-[440px] max-w-full overflow-hidden",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-white",
    headerSubtitle: "text-[#737373]",
    socialButtonsBlockButtonText: "text-white",
    formFieldLabel: "text-white",
    footerActionLink: "text-[#dc2626] hover:text-[#ef4444]",
    footerActionText: "text-[#737373]",
    dividerText: "text-[#737373]",
    identityPreviewEditButton: "text-[#dc2626]",
    formFieldSuccessText: "text-[#dc2626]",
    alertText: "text-white",
    logoBox: "flex justify-center py-4",
    logoImage: "h-16 w-auto drop-shadow-[0_0_16px_rgba(220,38,38,0.5)]",
    socialButtonsBlockButton: "border border-[#1f1f1f] bg-transparent hover:bg-[#1f1f1f]/50 text-white",
    formButtonPrimary: "bg-[#dc2626] hover:bg-[#b91c1c] text-white rounded-none font-bold tracking-widest",
    formFieldInput: "bg-[#1a1a1a] border-[#1f1f1f] text-white rounded-none focus:ring-[#dc2626]",
    footerAction: "bg-transparent",
    dividerLine: "bg-[#1f1f1f]",
    alert: "bg-[#0a0a0a] border border-[#1f1f1f]",
    otpCodeFieldInput: "border border-[#1f1f1f] bg-[#1a1a1a]",
    formFieldRow: "mb-4",
    main: "mt-4",
  },
};

function AuthPageWrapper({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 relative overflow-hidden">
      {/* Red glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at center, rgba(220,38,38,0.1) 0%, transparent 70%)' }} />
      {/* Corner brackets */}
      <div className="absolute top-8 left-8 w-8 h-8 border-t border-l border-primary/30 pointer-events-none" />
      <div className="absolute top-8 right-8 w-8 h-8 border-t border-r border-primary/30 pointer-events-none" />
      <div className="absolute bottom-8 left-8 w-8 h-8 border-b border-l border-primary/30 pointer-events-none" />
      <div className="absolute bottom-8 right-8 w-8 h-8 border-b border-r border-primary/30 pointer-events-none" />
      {/* Card wrapper with red border glow */}
      <div className="relative z-10 w-full max-w-md" style={{ boxShadow: '0 0 40px rgba(220,38,38,0.15)', border: '1px solid rgba(220,38,38,0.2)' }}>
        {children}
      </div>
    </div>
  );
}

function SignInPage() {
  return (
    <AuthPageWrapper>
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </AuthPageWrapper>
  );
}

function SignUpPage() {
  return (
    <AuthPageWrapper>
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </AuthPageWrapper>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        prevUserIdRef.current !== undefined &&
        prevUserIdRef.current !== userId
      ) {
        queryClient.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);

  return null;
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/dashboard" />
      </Show>
      <Show when="signed-out">
        <Home />
      </Show>
    </>
  );
}

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  return (
    <>
      <Show when="signed-in">
        <Layout>
          <Component />
        </Layout>
      </Show>
      <Show when="signed-out">
        <Redirect to="/" />
      </Show>
    </>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <TooltipProvider>
          <Switch>
            <Route path="/" component={HomeRedirect} />
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/*?" component={SignUpPage} />
            <Route path="/dashboard" component={() => <ProtectedRoute component={Dashboard} />} />
            <Route path="/cases" component={() => <ProtectedRoute component={Cases} />} />
            <Route path="/cases/:id" component={() => <ProtectedRoute component={CaseDetails} />} />
            <Route path="/billing" component={() => <ProtectedRoute component={Billing} />} />
            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
