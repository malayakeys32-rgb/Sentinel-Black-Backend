import { Link } from "wouter";
import { Terminal, Lock, Database, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center relative overflow-hidden font-mono">

      {/* Subtle scanline overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.03] z-0"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,255,255,0.1) 2px, rgba(255,255,255,0.1) 3px)',
          backgroundSize: '100% 3px',
        }}
      />

      {/* Red radial glow — center */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full pointer-events-none z-0"
        style={{ background: 'radial-gradient(ellipse at center, rgba(220,38,38,0.12) 0%, transparent 70%)' }} />

      {/* Top-left corner accent */}
      <div className="absolute top-0 left-0 w-32 h-32 pointer-events-none z-0"
        style={{ background: 'radial-gradient(ellipse at top left, rgba(220,38,38,0.08) 0%, transparent 70%)' }} />

      {/* Grid lines */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.06] z-0"
        style={{
          backgroundImage: 'linear-gradient(rgba(220,38,38,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(220,38,38,0.4) 1px, transparent 1px)',
          backgroundSize: '80px 80px',
        }} />

      {/* Corner brackets */}
      <div className="absolute top-6 left-6 w-10 h-10 border-t-2 border-l-2 border-primary/30 pointer-events-none z-10" />
      <div className="absolute top-6 right-6 w-10 h-10 border-t-2 border-r-2 border-primary/30 pointer-events-none z-10" />
      <div className="absolute bottom-6 left-6 w-10 h-10 border-b-2 border-l-2 border-primary/30 pointer-events-none z-10" />
      <div className="absolute bottom-6 right-6 w-10 h-10 border-b-2 border-r-2 border-primary/30 pointer-events-none z-10" />

      <div className="z-10 max-w-4xl w-full px-6 flex flex-col items-center text-center">

        {/* Logo */}
        <div className="mb-8 relative">
          <div className="absolute inset-0 rounded-full pointer-events-none"
            style={{ filter: 'blur(32px)', background: 'rgba(220,38,38,0.25)' }} />
          <img
            src="/sentinel-logo.png"
            alt="Sentinel Black Corporation"
            className="relative w-40 h-40 object-contain drop-shadow-[0_0_32px_rgba(220,38,38,0.6)]"
          />
        </div>

        {/* Title */}
        <div className="mb-3">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter text-white"
            style={{ textShadow: '0 0 40px rgba(220,38,38,0.3)' }}>
            SENTINEL
          </h1>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter text-primary -mt-2"
            style={{ textShadow: '0 0 40px rgba(220,38,38,0.6)' }}>
            BLACK
          </h1>
          <p className="text-xs tracking-[0.4em] text-muted-foreground mt-2 uppercase">CORPORATION</p>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-4 my-8 w-full max-w-lg">
          <div className="flex-1 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
          <Eye className="w-4 h-4 text-primary/60" />
          <div className="flex-1 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
        </div>

        <p className="text-base md:text-lg text-muted-foreground mb-12 max-w-xl leading-relaxed tracking-wide">
          Classified forensic intelligence console. Restricted access — authorized operatives and intelligence analysts only.
        </p>

        {/* Feature cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-px mb-12 w-full border border-primary/10 bg-primary/5">
          {[
            { icon: Lock, label: "Encrypted Access", desc: "End-to-end secure terminal for classified operational data." },
            { icon: Database, label: "Evidence Indexing", desc: "Structured forensic databasing with typed artifact tracking." },
            { icon: Terminal, label: "Command Interface", desc: "High-density information display for rapid field assessment." },
          ].map(({ icon: Icon, label, desc }) => (
            <div key={label} className="bg-card border-0 p-6 flex flex-col group hover:bg-primary/5 transition-colors">
              <div className="w-8 h-8 flex items-center justify-center border border-primary/20 mb-4 group-hover:border-primary/50 transition-colors">
                <Icon className="w-4 h-4 text-primary" />
              </div>
              <h3 className="font-bold text-white mb-2 text-sm tracking-widest uppercase">{label}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 w-full max-w-sm">
          <Link href="/sign-in" className="w-full">
            <Button
              className="w-full h-12 rounded-none font-bold tracking-widest text-sm relative overflow-hidden group border-0"
              style={{
                background: 'linear-gradient(135deg, #dc2626 0%, #b91c1c 100%)',
                boxShadow: '0 0 24px rgba(220,38,38,0.4), inset 0 1px 0 rgba(255,255,255,0.1)',
              }}
            >
              <span className="relative z-10 flex items-center justify-center gap-2 text-white">
                <Terminal className="w-4 h-4" />
                INITIATE_SESSION
              </span>
              <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
            </Button>
          </Link>
          <Link href="/sign-up" className="w-full">
            <Button
              variant="outline"
              className="w-full h-12 rounded-none font-bold tracking-widest text-sm text-white hover:text-primary transition-colors"
              style={{ borderColor: 'rgba(220,38,38,0.3)', background: 'transparent' }}
            >
              REQUEST_CLEARANCE
            </Button>
          </Link>
        </div>

        {/* Status bar */}
        <div className="mt-16 text-[10px] text-muted-foreground tracking-[0.3em] flex items-center gap-3 uppercase">
          <span className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
          Secure Node Configured — Awaiting Credentials
          <span className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
        </div>
      </div>
    </div>
  );
}
