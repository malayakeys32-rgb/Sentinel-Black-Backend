import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { CreditCard, Shield, Zap, CheckCircle, ChevronRight, Loader2, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface Price {
  id: string;
  unitAmount: number;
  currency: string;
  recurring: { interval: string } | null;
}

interface Product {
  id: string;
  name: string;
  description: string | null;
  prices: Price[];
}

interface Subscription {
  id: string;
  status: string;
  current_period_end: string;
}

export default function Billing() {
  const { toast } = useToast();
  const [location] = useLocation();

  const [products, setProducts] = useState<Product[]>([]);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [plan, setPlan] = useState<"free" | "pro">("free");
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [loadingSub, setLoadingSub] = useState(true);
  const [checkoutLoading, setCheckoutLoading] = useState<string | null>(null);
  const [portalLoading, setPortalLoading] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const status = params.get("status");
    if (status === "success") {
      toast({ title: "SUBSCRIPTION_ACTIVATED", description: "Your Pro access has been enabled. Welcome to the inner circle." });
    } else if (status === "cancelled") {
      toast({ title: "CHECKOUT_CANCELLED", description: "Subscription was not completed.", variant: "destructive" });
    }
  }, []);

  useEffect(() => {
    fetch("/api/billing/products")
      .then(r => r.json())
      .then(d => setProducts(d.data ?? []))
      .catch(() => setProducts([]))
      .finally(() => setLoadingProducts(false));

    fetch("/api/billing/subscription")
      .then(r => r.json())
      .then(d => {
        setSubscription(d.subscription);
        setPlan(d.plan ?? "free");
      })
      .catch(() => {})
      .finally(() => setLoadingSub(false));
  }, []);

  const handleCheckout = async (priceId: string) => {
    setCheckoutLoading(priceId);
    try {
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ priceId }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error(data.error ?? "No checkout URL returned");
      }
    } catch (err: any) {
      toast({ title: "CHECKOUT_FAILED", description: err.message, variant: "destructive" });
    } finally {
      setCheckoutLoading(null);
    }
  };

  const handlePortal = async () => {
    setPortalLoading(true);
    try {
      const res = await fetch("/api/billing/portal", { method: "POST" });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error(data.error ?? "No portal URL returned");
      }
    } catch (err: any) {
      toast({ title: "PORTAL_FAILED", description: err.message, variant: "destructive" });
    } finally {
      setPortalLoading(false);
    }
  };

  const formatAmount = (amount: number, currency: string) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency }).format(amount / 100);

  const getIntervalLabel = (price: Price) => {
    if (!price.recurring) return "one-time";
    return price.recurring.interval === "year" ? "/ year" : "/ month";
  };

  const proFeatures = [
    "Unlimited case records",
    "AI intelligence summaries",
    "Evidence file storage",
    "Priority case tagging",
    "Advanced analytics",
    "Priority support",
  ];

  const freeFeatures = [
    "Up to 5 active cases",
    "Manual evidence logging",
    "Basic case management",
    "Standard support",
  ];

  const proProduct = products[0] ?? null;
  const monthlyPrice = proProduct?.prices.find(p => p.recurring?.interval === "month") ?? null;
  const yearlyPrice = proProduct?.prices.find(p => p.recurring?.interval === "year") ?? null;

  return (
    <div className="p-8 max-w-6xl mx-auto font-mono">
      {/* Header */}
      <div className="mb-10 pb-4 border-b border-border">
        <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
          <CreditCard className="w-8 h-8 text-primary" />
          BILLING_ACCESS_TIER
        </h1>
        <p className="text-muted-foreground mt-1">Manage your Sentinel Black subscription and access level.</p>
      </div>

      {/* Current Status */}
      <div
        className="mb-10 p-6 relative overflow-hidden"
        style={{
          background: plan === "pro" ? "rgba(220,38,38,0.06)" : "rgba(255,255,255,0.03)",
          border: plan === "pro" ? "1px solid rgba(220,38,38,0.3)" : "1px solid rgba(255,255,255,0.08)",
          boxShadow: plan === "pro" ? "0 0 30px rgba(220,38,38,0.1)" : "none",
        }}
      >
        <div className="absolute top-0 right-0 w-12 h-12 border-t-2 border-r-2 border-primary/20 m-3" />
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <div
              className="w-12 h-12 flex items-center justify-center"
              style={{ border: "1px solid rgba(220,38,38,0.4)", background: "rgba(220,38,38,0.1)" }}
            >
              {plan === "pro" ? (
                <Crown className="w-6 h-6 text-primary" />
              ) : (
                <Shield className="w-6 h-6 text-muted-foreground" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h2 className="text-xl font-bold text-white tracking-widest">
                  {plan === "pro" ? "PRO_OPERATIVE" : "FREE_TIER"}
                </h2>
                <Badge
                  variant="outline"
                  className={`rounded-none uppercase text-[10px] font-bold ${
                    plan === "pro" ? "text-primary border-primary/50" : "text-muted-foreground border-muted-foreground/30"
                  }`}
                >
                  {loadingSub ? "..." : plan.toUpperCase()}
                </Badge>
              </div>
              {plan === "pro" && subscription && (
                <p className="text-sm text-muted-foreground mt-1">
                  STATUS: {subscription.status.toUpperCase()} — Renews {new Date((subscription as any).current_period_end * 1000).toLocaleDateString()}
                </p>
              )}
              {plan === "free" && (
                <p className="text-sm text-muted-foreground mt-1">
                  Upgrade to Pro for full intelligence capabilities.
                </p>
              )}
            </div>
          </div>
          {plan === "pro" && (
            <Button
              variant="outline"
              className="rounded-none border-primary/30 text-primary hover:bg-primary/10 font-bold tracking-widest text-xs"
              onClick={handlePortal}
              disabled={portalLoading}
            >
              {portalLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <CreditCard className="w-4 h-4 mr-2" />}
              MANAGE_BILLING
            </Button>
          )}
        </div>
      </div>

      {/* Pricing Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Free Tier */}
        <div
          className="p-6 relative"
          style={{ border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.02)" }}
        >
          <div className="mb-6">
            <p className="text-xs text-muted-foreground tracking-widest uppercase mb-1">Current Plan</p>
            <h3 className="text-2xl font-bold text-white tracking-wider">FREE</h3>
            <p className="text-3xl font-bold text-white mt-2">$0</p>
            <p className="text-xs text-muted-foreground">Forever</p>
          </div>
          <ul className="space-y-3 mb-8">
            {freeFeatures.map((f) => (
              <li key={f} className="flex items-start gap-2 text-sm text-muted-foreground">
                <CheckCircle className="w-4 h-4 text-muted-foreground/50 mt-0.5 flex-shrink-0" />
                {f}
              </li>
            ))}
          </ul>
          <Button
            variant="outline"
            className="w-full rounded-none border-border text-muted-foreground cursor-default"
            disabled
          >
            CURRENT_TIER
          </Button>
        </div>

        {/* Pro Monthly */}
        <div
          className="p-6 relative"
          style={{
            border: "1px solid rgba(220,38,38,0.4)",
            background: "rgba(220,38,38,0.05)",
            boxShadow: "0 0 40px rgba(220,38,38,0.12)",
          }}
        >
          <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent" />
          <div className="mb-6">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs text-primary tracking-widest uppercase">Pro Access</p>
              <Badge variant="outline" className="rounded-none text-[9px] text-primary border-primary/40">MONTHLY</Badge>
            </div>
            <h3 className="text-2xl font-bold text-white tracking-wider">PRO</h3>
            {loadingProducts ? (
              <div className="h-9 w-24 bg-muted/20 animate-pulse mt-2" />
            ) : (
              <>
                <p className="text-3xl font-bold text-white mt-2">
                  {monthlyPrice ? formatAmount(monthlyPrice.unitAmount, monthlyPrice.currency) : "—"}
                </p>
                <p className="text-xs text-muted-foreground">per month</p>
              </>
            )}
          </div>
          <ul className="space-y-3 mb-8">
            {proFeatures.map((f) => (
              <li key={f} className="flex items-start gap-2 text-sm text-foreground/80">
                <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                {f}
              </li>
            ))}
          </ul>
          {plan === "pro" ? (
            <Button variant="outline" className="w-full rounded-none border-primary/40 text-primary" disabled>
              <Crown className="w-4 h-4 mr-2" />ACTIVE
            </Button>
          ) : (
            <Button
              className="w-full rounded-none font-bold tracking-widest text-sm text-white"
              style={{
                background: "linear-gradient(135deg, #dc2626, #b91c1c)",
                boxShadow: "0 0 20px rgba(220,38,38,0.3)",
              }}
              disabled={!monthlyPrice || checkoutLoading === monthlyPrice?.id}
              onClick={() => monthlyPrice && handleCheckout(monthlyPrice.id)}
            >
              {checkoutLoading === monthlyPrice?.id ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Zap className="w-4 h-4 mr-2" />
              )}
              UPGRADE_MONTHLY
              <ChevronRight className="w-4 h-4 ml-auto" />
            </Button>
          )}
        </div>

        {/* Pro Annual */}
        <div
          className="p-6 relative"
          style={{
            border: "1px solid rgba(220,38,38,0.25)",
            background: "rgba(220,38,38,0.03)",
          }}
        >
          <div className="absolute -top-3 left-1/2 -translate-x-1/2">
            <span className="bg-primary text-white text-[10px] font-bold tracking-widest px-3 py-1">
              SAVE 17%
            </span>
          </div>
          <div className="mb-6 mt-3">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs text-primary/70 tracking-widest uppercase">Best Value</p>
              <Badge variant="outline" className="rounded-none text-[9px] text-primary/70 border-primary/20">ANNUAL</Badge>
            </div>
            <h3 className="text-2xl font-bold text-white tracking-wider">PRO</h3>
            {loadingProducts ? (
              <div className="h-9 w-24 bg-muted/20 animate-pulse mt-2" />
            ) : (
              <>
                <p className="text-3xl font-bold text-white mt-2">
                  {yearlyPrice ? formatAmount(yearlyPrice.unitAmount, yearlyPrice.currency) : "—"}
                </p>
                <p className="text-xs text-muted-foreground">per year</p>
              </>
            )}
          </div>
          <ul className="space-y-3 mb-8">
            {proFeatures.map((f) => (
              <li key={f} className="flex items-start gap-2 text-sm text-foreground/80">
                <CheckCircle className="w-4 h-4 text-primary/70 mt-0.5 flex-shrink-0" />
                {f}
              </li>
            ))}
          </ul>
          {plan === "pro" ? (
            <Button variant="outline" className="w-full rounded-none border-primary/40 text-primary" disabled>
              <Crown className="w-4 h-4 mr-2" />ACTIVE
            </Button>
          ) : (
            <Button
              variant="outline"
              className="w-full rounded-none font-bold tracking-widest text-sm border-primary/40 text-primary hover:bg-primary/10"
              disabled={!yearlyPrice || checkoutLoading === yearlyPrice?.id}
              onClick={() => yearlyPrice && handleCheckout(yearlyPrice.id)}
            >
              {checkoutLoading === yearlyPrice?.id ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Zap className="w-4 h-4 mr-2" />
              )}
              UPGRADE_ANNUAL
              <ChevronRight className="w-4 h-4 ml-auto" />
            </Button>
          )}
        </div>
      </div>

      {/* Footer note */}
      <p className="text-center text-xs text-muted-foreground mt-10 opacity-50">
        Payments securely processed by Stripe. Cancel anytime from the billing portal.
      </p>
    </div>
  );
}
