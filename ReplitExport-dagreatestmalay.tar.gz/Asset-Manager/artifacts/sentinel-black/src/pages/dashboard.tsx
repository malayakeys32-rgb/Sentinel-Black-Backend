import { useState } from "react";
import { Link } from "wouter";
import { format } from "date-fns";
import { useGetDashboardStats, useGetRecentCases, useCreateCase, getGetDashboardStatsQueryKey, getGetRecentCasesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Terminal, Activity, FileDigit, Briefcase, Plus, AlertTriangle, ShieldCheck, Clock } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";

const caseSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters").max(100, "Title is too long"),
  description: z.string().optional(),
  status: z.enum(["open", "in-progress", "closed", "archived"]),
  priority: z.enum(["low", "medium", "high", "critical"]),
});

type CaseFormValues = z.infer<typeof caseSchema>;

export default function Dashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const { data: stats, isLoading: statsLoading } = useGetDashboardStats();
  const { data: recentCases, isLoading: casesLoading } = useGetRecentCases();
  const createCase = useCreateCase();

  const form = useForm<CaseFormValues>({
    resolver: zodResolver(caseSchema),
    defaultValues: {
      title: "",
      description: "",
      status: "open",
      priority: "medium",
    },
  });

  const onSubmit = (data: CaseFormValues) => {
    createCase.mutate({ data }, {
      onSuccess: () => {
        toast({
          title: "CASE_INITIALIZED",
          description: "New case record has been established in the index.",
        });
        setIsCreateModalOpen(false);
        form.reset();
        queryClient.invalidateQueries({ queryKey: getGetDashboardStatsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetRecentCasesQueryKey() });
      },
      onError: (error) => {
        toast({
          title: "INITIALIZATION_FAILED",
          description: "Failed to establish case record. Check connection.",
          variant: "destructive",
        });
      }
    });
  };

  const getPriorityColor = (priority: string | null | undefined) => {
    switch (priority) {
      case 'critical': return 'text-red-500 bg-red-500/10 border-red-500/20';
      case 'high': return 'text-orange-500 bg-orange-500/10 border-orange-500/20';
      case 'medium': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      case 'low': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      default: return 'text-muted-foreground bg-muted/10 border-muted/20';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'text-primary border-primary/50';
      case 'in-progress': return 'text-yellow-500 border-yellow-500/50';
      case 'closed': return 'text-white border-white/30';
      case 'archived': return 'text-muted-foreground border-muted-foreground/30';
      default: return 'text-muted-foreground border-muted-foreground/30';
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto font-mono">
      <div className="flex items-center justify-between mb-8 pb-4 border-b border-border">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
            <Terminal className="w-8 h-8 text-primary" />
            OPERATIONAL_DASHBOARD
          </h1>
          <p className="text-muted-foreground mt-1">Intelligence overview and recent activity.</p>
        </div>
        
        <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-none bg-primary text-background hover:bg-primary/90 font-bold border border-primary relative group overflow-hidden">
              <span className="relative z-10 flex items-center gap-2">
                <Plus className="w-4 h-4" />
                INITIATE_CASE
              </span>
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border border-border rounded-none sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold text-foreground border-b border-border pb-2 flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-primary" />
                NEW_CASE_RECORD
              </DialogTitle>
              <DialogDescription className="text-muted-foreground pt-2">
                Enter initial intelligence parameters for the new case.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground">DESIGNATION / TITLE</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Operation Nightfall" className="bg-background rounded-none border-border focus-visible:ring-primary" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">INITIAL_STATUS</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-background rounded-none border-border focus:ring-primary">
                              <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-card border-border rounded-none">
                            <SelectItem value="open">OPEN</SelectItem>
                            <SelectItem value="in-progress">IN_PROGRESS</SelectItem>
                            <SelectItem value="closed">CLOSED</SelectItem>
                            <SelectItem value="archived">ARCHIVED</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="priority"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">PRIORITY_LEVEL</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-background rounded-none border-border focus:ring-primary">
                              <SelectValue placeholder="Select priority" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-card border-border rounded-none">
                            <SelectItem value="low">LOW</SelectItem>
                            <SelectItem value="medium">MEDIUM</SelectItem>
                            <SelectItem value="high">HIGH</SelectItem>
                            <SelectItem value="critical">CRITICAL</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground">INITIAL_BRIEFING</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Provide initial intelligence briefing..." 
                          className="bg-background rounded-none border-border focus-visible:ring-primary min-h-[100px]" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="pt-4 flex justify-end gap-3">
                  <Button type="button" variant="outline" onClick={() => setIsCreateModalOpen(false)} className="rounded-none border-border text-foreground hover:bg-muted/50">
                    CANCEL
                  </Button>
                  <Button type="submit" disabled={createCase.isPending} className="rounded-none bg-primary text-background hover:bg-primary/90 font-bold border border-primary">
                    {createCase.isPending ? "INITIALIZING..." : "CONFIRM_INITIALIZATION"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="bg-card border-border rounded-none">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">TOTAL_CASES</CardTitle>
            <Briefcase className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {statsLoading ? <div className="h-8 w-16 bg-muted animate-pulse"></div> : stats?.totalCases || 0}
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border rounded-none">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">ACTIVE_CASES</CardTitle>
            <Activity className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {statsLoading ? <div className="h-8 w-16 bg-muted animate-pulse"></div> : stats?.openCases || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Requires attention</p>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border rounded-none">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">RESOLVED</CardTitle>
            <ShieldCheck className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {statsLoading ? <div className="h-8 w-16 bg-muted animate-pulse"></div> : stats?.closedCases || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Closed or archived</p>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border rounded-none">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">EVIDENCE_INDEX</CardTitle>
            <FileDigit className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {statsLoading ? <div className="h-8 w-16 bg-muted animate-pulse"></div> : stats?.totalEvidence || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Logged artifacts</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Cases */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold tracking-tight text-foreground flex items-center gap-2 border-b border-border pb-2">
          <Clock className="w-5 h-5 text-primary" />
          RECENT_ACTIVITY_LOG
        </h2>
        
        {casesLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 bg-card border border-border animate-pulse"></div>
            ))}
          </div>
        ) : recentCases && recentCases.length > 0 ? (
          <div className="grid gap-3">
            {recentCases.map((caseItem) => (
              <Link key={caseItem.id} href={`/cases/${caseItem.id}`}>
                <div className="group block bg-card border border-border p-4 hover:border-primary/50 hover:bg-card/80 transition-all cursor-pointer relative overflow-hidden">
                  {/* Decorative corner accent */}
                  <div className="absolute top-0 right-0 w-2 h-2 bg-transparent border-t border-r border-primary/50 group-hover:border-primary transition-colors m-2"></div>
                  
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-xs text-muted-foreground font-mono">ID:{String(caseItem.id).padStart(4, '0')}</span>
                        <h3 className="font-bold text-lg text-foreground group-hover:text-primary transition-colors">{caseItem.title}</h3>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-1 max-w-2xl">
                        {caseItem.description || "No briefing provided."}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <Badge variant="outline" className={`rounded-none uppercase font-bold text-[10px] ${getStatusColor(caseItem.status)}`}>
                        {caseItem.status}
                      </Badge>
                      <Badge variant="outline" className={`rounded-none uppercase font-bold text-[10px] border ${getPriorityColor(caseItem.priority)}`}>
                        {caseItem.priority || 'UNRATED'}
                      </Badge>
                    </div>
                  </div>
                  <div className="mt-4 text-xs text-muted-foreground flex items-center gap-4">
                    <span>CREATED: {format(new Date(caseItem.createdAt), 'yyyy-MM-dd HH:mm')}</span>
                    <span>UPDATED: {format(new Date(caseItem.updatedAt), 'yyyy-MM-dd HH:mm')}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="bg-card border border-dashed border-border p-12 text-center flex flex-col items-center justify-center">
            <AlertTriangle className="w-12 h-12 text-muted-foreground mb-4 opacity-50" />
            <h3 className="text-lg font-bold text-foreground">NO_RECORDS_FOUND</h3>
            <p className="text-muted-foreground max-w-md mt-2">
              The intelligence database is currently empty. Initiate a new case to begin operations.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
