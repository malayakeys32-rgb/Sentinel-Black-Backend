import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { format } from "date-fns";
import { 
  useGetCase, 
  useUpdateCase, 
  useDeleteCase,
  useListEvidence,
  useCreateEvidence,
  useDeleteEvidence,
  useListSummaries,
  useGenerateSummary,
  getGetCaseQueryKey, 
  getListEvidenceQueryKey,
  getGetDashboardStatsQueryKey,
  getGetRecentCasesQueryKey,
  getListSummariesQueryKey,
} from "@workspace/api-client-react";
import { useUpload } from "@workspace/object-storage-web";
import { useQueryClient } from "@tanstack/react-query";
import { 
  Briefcase, ArrowLeft, Save, Trash2, Database, Plus, 
  FileText, Image as ImageIcon, Video, Mic, HardDrive, 
  User, ShieldAlert, X, Terminal, Sparkles, Upload, Paperclip, Download
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";

const evidenceSchema = z.object({
  label: z.string().min(3, "Label required").max(100),
  type: z.enum(["document", "photo", "audio", "video", "physical", "digital", "testimony"]),
  notes: z.string().optional(),
});

type EvidenceFormValues = z.infer<typeof evidenceSchema>;

export default function CaseDetails() {
  const params = useParams();
  const id = Number(params.id);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isEditing, setIsEditing] = useState(false);
  const [isEvidenceModalOpen, setIsEvidenceModalOpen] = useState(false);
  const [pendingObjectPath, setPendingObjectPath] = useState<string | null>(null);
  const [pendingFileName, setPendingFileName] = useState<string | null>(null);
  
  const [editTitle, setEditTitle] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editStatus, setEditStatus] = useState("open");
  const [editPriority, setEditPriority] = useState("medium");

  const { data: caseItem, isLoading: caseLoading } = useGetCase(id, {
    query: { enabled: !!id && !isNaN(id), queryKey: getGetCaseQueryKey(id) }
  });

  const { data: evidence, isLoading: evidenceLoading } = useListEvidence(id, {
    query: { enabled: !!id && !isNaN(id), queryKey: getListEvidenceQueryKey(id) }
  });

  const { data: summaries, isLoading: summariesLoading } = useListSummaries(id, {
    query: { enabled: !!id && !isNaN(id), queryKey: getListSummariesQueryKey(id) }
  });

  const updateCase = useUpdateCase();
  const deleteCase = useDeleteCase();
  const createEvidence = useCreateEvidence();
  const deleteEvidenceMutation = useDeleteEvidence();
  const generateSummary = useGenerateSummary();

  const { uploadFile, isUploading, progress } = useUpload({
    onSuccess: (response) => {
      setPendingObjectPath(response.objectPath);
    },
    onError: (err) => {
      toast({
        title: "UPLOAD_FAILED",
        description: err.message,
        variant: "destructive",
      });
    },
  });

  const evidenceForm = useForm<EvidenceFormValues>({
    resolver: zodResolver(evidenceSchema),
    defaultValues: { label: "", type: "document", notes: "" },
  });

  useEffect(() => {
    if (caseItem && !isEditing) {
      setEditTitle(caseItem.title);
      setEditDescription(caseItem.description || "");
      setEditStatus(caseItem.status);
      setEditPriority(caseItem.priority || "medium");
    }
  }, [caseItem, isEditing]);

  if (!id || isNaN(id)) {
    return <div className="p-8 text-center font-mono">INVALID_CASE_ID</div>;
  }

  const handleSave = () => {
    updateCase.mutate({ id, data: { title: editTitle, description: editDescription, status: editStatus, priority: editPriority } }, {
      onSuccess: (updatedData) => {
        setIsEditing(false);
        queryClient.setQueryData(getGetCaseQueryKey(id), updatedData);
        queryClient.invalidateQueries({ queryKey: getGetDashboardStatsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetRecentCasesQueryKey() });
        toast({ title: "RECORD_UPDATED", description: "Case file modifications saved to index." });
      },
      onError: () => toast({ title: "UPDATE_FAILED", description: "Could not save modifications.", variant: "destructive" }),
    });
  };

  const handleDelete = () => {
    deleteCase.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetDashboardStatsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetRecentCasesQueryKey() });
        toast({ title: "RECORD_EXPUNGED", description: "Case file deleted from index." });
        setLocation("/cases");
      },
      onError: () => toast({ title: "DELETION_FAILED", description: "Could not expunge record.", variant: "destructive" }),
    });
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPendingFileName(file.name);
    await uploadFile(file);
  };

  const onAddEvidence = (data: EvidenceFormValues) => {
    createEvidence.mutate({ id, data: { label: data.label, type: data.type, notes: data.notes, objectPath: pendingObjectPath ?? undefined } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListEvidenceQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getGetDashboardStatsQueryKey() });
        setIsEvidenceModalOpen(false);
        setPendingObjectPath(null);
        setPendingFileName(null);
        evidenceForm.reset();
        toast({ title: "EVIDENCE_LOGGED", description: "New artifact added to case index." });
      },
      onError: () => toast({ title: "LOGGING_FAILED", description: "Failed to record evidence artifact.", variant: "destructive" }),
    });
  };

  const handleDeleteEvidence = (evidenceId: number) => {
    deleteEvidenceMutation.mutate({ id: evidenceId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListEvidenceQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getGetDashboardStatsQueryKey() });
        toast({ title: "EVIDENCE_REMOVED", description: "Artifact deleted from index." });
      },
      onError: () => toast({ title: "REMOVAL_FAILED", description: "Could not delete artifact.", variant: "destructive" }),
    });
  };

  const handleGenerateSummary = () => {
    generateSummary.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSummariesQueryKey(id) });
        toast({ title: "ANALYSIS_COMPLETE", description: "Intelligence summary generated and stored." });
      },
      onError: () => toast({ title: "ANALYSIS_FAILED", description: "AI summary generation failed.", variant: "destructive" }),
    });
  };

  const getPriorityColor = (priority: string | null | undefined) => {
    switch (priority) {
      case 'critical': return 'text-red-500 bg-red-500/10 border-red-500/20';
      case 'high': return 'text-orange-500 bg-orange-500/10 border-orange-500/20';
      case 'medium': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      case 'low': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      default: return 'text-muted-foreground bg-muted/10 border-muted/20';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'text-primary border-primary/50';
      case 'in-progress': return 'text-yellow-500 border-yellow-500/50';
      case 'closed': return 'text-white border-white/30';
      case 'archived': return 'text-muted-foreground border-muted-foreground/30';
      default: return 'text-muted-foreground border-muted-foreground/30';
    }
  };

  const getEvidenceIcon = (type: string) => {
    switch (type) {
      case 'document': return <FileText className="w-5 h-5 text-blue-400" />;
      case 'photo': return <ImageIcon className="w-5 h-5 text-purple-400" />;
      case 'video': return <Video className="w-5 h-5 text-red-400" />;
      case 'audio': return <Mic className="w-5 h-5 text-yellow-400" />;
      case 'physical': return <Briefcase className="w-5 h-5 text-orange-400" />;
      case 'digital': return <HardDrive className="w-5 h-5 text-primary" />;
      case 'testimony': return <User className="w-5 h-5 text-pink-400" />;
      default: return <Database className="w-5 h-5 text-muted-foreground" />;
    }
  };

  if (caseLoading) {
    return (
      <div className="p-8 max-w-7xl mx-auto space-y-8 animate-pulse">
        <div className="h-12 w-1/3 bg-card border border-border"></div>
        <div className="h-64 bg-card border border-border"></div>
        <div className="h-64 bg-card border border-border"></div>
      </div>
    );
  }

  if (!caseItem) {
    return (
      <div className="p-8 max-w-7xl mx-auto text-center flex flex-col items-center justify-center font-mono">
        <ShieldAlert className="w-16 h-16 text-destructive mb-4" />
        <h2 className="text-2xl font-bold">RECORD_NOT_FOUND</h2>
        <p className="text-muted-foreground mt-2">This case file does not exist or access is restricted.</p>
        <Button variant="outline" className="mt-6 rounded-none" onClick={() => setLocation("/cases")}>
          <ArrowLeft className="w-4 h-4 mr-2" />RETURN_TO_INDEX
        </Button>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-7xl mx-auto font-mono">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 pb-4 border-b border-border gap-4">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="rounded-none hover:bg-muted/50 border border-transparent hover:border-border" onClick={() => setLocation("/cases")}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
                <Briefcase className="w-6 h-6 text-primary" />
                {isEditing ? "EDITING_RECORD" : caseItem.title}
              </h1>
              {!isEditing && (
                <>
                  <Badge variant="outline" className={`rounded-none uppercase font-bold text-[10px] ${getStatusColor(caseItem.status)}`}>{caseItem.status}</Badge>
                  <Badge variant="outline" className={`rounded-none uppercase font-bold text-[10px] border ${getPriorityColor(caseItem.priority)}`}>{caseItem.priority || 'UNRATED'}</Badge>
                </>
              )}
            </div>
            <p className="text-muted-foreground mt-1 text-sm">
              ID: {String(caseItem.id).padStart(4, '0')} | CREATED: {format(new Date(caseItem.createdAt), 'yyyy-MM-dd HH:mm')} | UPDATED: {format(new Date(caseItem.updatedAt), 'yyyy-MM-dd HH:mm')}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {isEditing ? (
            <>
              <Button variant="outline" className="rounded-none border-border hover:bg-muted/50" onClick={() => setIsEditing(false)} disabled={updateCase.isPending}>CANCEL</Button>
              <Button className="rounded-none bg-primary text-background hover:bg-primary/90 font-bold border border-primary" onClick={handleSave} disabled={updateCase.isPending}>
                <Save className="w-4 h-4 mr-2" />{updateCase.isPending ? "SAVING..." : "COMMIT_CHANGES"}
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" className="rounded-none border-border hover:bg-primary/10 hover:text-primary hover:border-primary/50" onClick={() => setIsEditing(true)}>MODIFY_RECORD</Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" className="rounded-none border-border text-destructive hover:bg-destructive/10 hover:border-destructive/50">
                    <Trash2 className="w-4 h-4 mr-2" />EXPUNGE
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-card border-destructive/50 rounded-none font-mono">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-destructive flex items-center gap-2"><ShieldAlert className="w-5 h-5" />CONFIRM_EXPUNGEMENT</AlertDialogTitle>
                    <AlertDialogDescription className="text-muted-foreground">
                      This action will permanently delete case {String(caseItem.id).padStart(4, '0')} and all associated evidence records. This action cannot be reversed.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="rounded-none border-border hover:bg-muted/50">ABORT</AlertDialogCancel>
                    <AlertDialogAction className="rounded-none bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>EXECUTE_EXPUNGE</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Case Info */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-card border border-border p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-8 h-8 bg-transparent border-t border-r border-primary/30 m-2"></div>
            <h3 className="text-lg font-bold text-foreground flex items-center gap-2 mb-6 border-b border-border/50 pb-2">
              <Terminal className="w-5 h-5 text-primary" />INTELLIGENCE_BRIEFING
            </h3>
            {isEditing ? (
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-muted-foreground">DESIGNATION / TITLE</label>
                  <Input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} className="bg-background rounded-none border-border focus-visible:ring-primary font-bold text-lg" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-muted-foreground">STATUS</label>
                    <Select value={editStatus} onValueChange={setEditStatus}>
                      <SelectTrigger className="bg-background rounded-none border-border focus:ring-primary"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-card border-border rounded-none">
                        <SelectItem value="open">OPEN</SelectItem>
                        <SelectItem value="in-progress">IN_PROGRESS</SelectItem>
                        <SelectItem value="closed">CLOSED</SelectItem>
                        <SelectItem value="archived">ARCHIVED</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-muted-foreground">PRIORITY</label>
                    <Select value={editPriority} onValueChange={setEditPriority}>
                      <SelectTrigger className="bg-background rounded-none border-border focus:ring-primary"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-card border-border rounded-none">
                        <SelectItem value="low">LOW</SelectItem>
                        <SelectItem value="medium">MEDIUM</SelectItem>
                        <SelectItem value="high">HIGH</SelectItem>
                        <SelectItem value="critical">CRITICAL</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-muted-foreground">BRIEFING_DETAILS</label>
                  <Textarea value={editDescription} onChange={(e) => setEditDescription(e.target.value)} className="bg-background rounded-none border-border focus-visible:ring-primary min-h-[200px]" />
                </div>
              </div>
            ) : (
              <div className="prose prose-invert max-w-none text-muted-foreground">
                {caseItem.description ? (
                  caseItem.description.split('\n').map((paragraph, i) => (
                    <p key={i} className="mb-4 leading-relaxed">{paragraph}</p>
                  ))
                ) : (
                  <p className="italic opacity-50">No briefing details provided for this record.</p>
                )}
              </div>
            )}
          </div>

          {/* AI Intelligence Summaries */}
          <div className="bg-card border border-border p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-8 h-8 bg-transparent border-t border-r border-primary/30 m-2"></div>
            <div className="flex items-center justify-between border-b border-border/50 pb-2 mb-6">
              <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />AI_INTELLIGENCE_ANALYSIS
              </h3>
              <Button
                size="sm"
                className="rounded-none bg-primary/10 text-primary hover:bg-primary/20 border border-primary/30 font-bold text-xs"
                onClick={handleGenerateSummary}
                disabled={generateSummary.isPending}
              >
                <Sparkles className="w-3 h-3 mr-2" />
                {generateSummary.isPending ? "ANALYZING..." : "GENERATE_BRIEF"}
              </Button>
            </div>

            {summariesLoading ? (
              <div className="space-y-3">
                {[1, 2].map((i) => <div key={i} className="h-24 bg-muted/10 border border-border animate-pulse"></div>)}
              </div>
            ) : summaries && summaries.length > 0 ? (
              <div className="space-y-4">
                {summaries.map((summary) => (
                  <div key={summary.id} className="border border-border/50 bg-background/50 p-4 relative">
                    <div className="absolute top-0 left-0 w-1 h-full bg-primary/30"></div>
                    <div className="text-xs text-muted-foreground mb-3 font-bold">
                      BRIEF_GENERATED: {format(new Date(summary.createdAt), 'yyyy-MM-dd HH:mm:ss')}
                    </div>
                    <pre className="text-xs text-foreground/80 whitespace-pre-wrap font-mono leading-relaxed">
                      {summary.content}
                    </pre>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 border border-dashed border-border">
                <Sparkles className="w-8 h-8 text-muted-foreground mx-auto mb-3 opacity-30" />
                <p className="text-sm text-muted-foreground">No intelligence briefs generated yet.</p>
                <p className="text-xs text-muted-foreground mt-1 opacity-60">Generate a summary to run AI analysis on this case and its evidence.</p>
              </div>
            )}
          </div>
        </div>

        {/* Evidence Sidebar */}
        <div className="space-y-6">
          <div className="bg-card border border-border p-6 relative">
            <div className="flex items-center justify-between border-b border-border/50 pb-2 mb-4">
              <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
                <Database className="w-5 h-5 text-primary" />EVIDENCE_INDEX
              </h3>
              <Dialog open={isEvidenceModalOpen} onOpenChange={(open) => {
                setIsEvidenceModalOpen(open);
                if (!open) { setPendingObjectPath(null); setPendingFileName(null); evidenceForm.reset(); }
              }}>
                <DialogTrigger asChild>
                  <Button size="icon" variant="ghost" className="h-8 w-8 rounded-none hover:bg-primary/10 hover:text-primary">
                    <Plus className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-card border border-border rounded-none font-mono">
                  <DialogHeader>
                    <DialogTitle className="text-xl font-bold text-foreground border-b border-border pb-2 flex items-center gap-2">
                      <Database className="w-5 h-5 text-primary" />LOG_ARTIFACT
                    </DialogTitle>
                    <DialogDescription className="text-muted-foreground pt-2">
                      Enter evidence details and optionally attach a file.
                    </DialogDescription>
                  </DialogHeader>
                  <Form {...evidenceForm}>
                    <form onSubmit={evidenceForm.handleSubmit(onAddEvidence)} className="space-y-4 pt-4">
                      <FormField control={evidenceForm.control} name="label" render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground">ARTIFACT_LABEL</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Surveillance footage #1" className="bg-background rounded-none border-border focus-visible:ring-primary" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={evidenceForm.control} name="type" render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground">ARTIFACT_TYPE</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-background rounded-none border-border focus:ring-primary"><SelectValue placeholder="Select type" /></SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-card border-border rounded-none">
                              <SelectItem value="document">DOCUMENT</SelectItem>
                              <SelectItem value="photo">PHOTOGRAPH</SelectItem>
                              <SelectItem value="video">VIDEO_RECORDING</SelectItem>
                              <SelectItem value="audio">AUDIO_RECORDING</SelectItem>
                              <SelectItem value="physical">PHYSICAL_ITEM</SelectItem>
                              <SelectItem value="digital">DIGITAL_DATA</SelectItem>
                              <SelectItem value="testimony">WITNESS_TESTIMONY</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={evidenceForm.control} name="notes" render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground">ANALYSIS_NOTES</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Enter analytical observations..." className="bg-background rounded-none border-border focus-visible:ring-primary min-h-[80px]" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />

                      {/* File Upload */}
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-foreground">ATTACH_FILE <span className="text-muted-foreground font-normal">(optional)</span></label>
                        <label className={`flex items-center gap-3 border border-dashed p-3 cursor-pointer transition-colors ${isUploading ? 'border-primary/50 bg-primary/5' : 'border-border hover:border-primary/40 hover:bg-muted/10'}`}>
                          <Upload className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                          <span className="text-xs text-muted-foreground truncate">
                            {isUploading ? `UPLOADING... ${progress}%` : pendingFileName ? pendingFileName : "Click to attach file"}
                          </span>
                          {pendingObjectPath && <Paperclip className="w-3 h-3 text-primary flex-shrink-0 ml-auto" />}
                          <input type="file" className="hidden" onChange={handleFileSelect} disabled={isUploading} />
                        </label>
                        {pendingObjectPath && (
                          <p className="text-[10px] text-primary">FILE_ATTACHED: Ready to commit with artifact</p>
                        )}
                      </div>

                      <div className="pt-4 flex justify-end gap-3">
                        <Button type="button" variant="outline" onClick={() => setIsEvidenceModalOpen(false)} className="rounded-none border-border text-foreground hover:bg-muted/50">CANCEL</Button>
                        <Button type="submit" disabled={createEvidence.isPending || isUploading} className="rounded-none bg-primary text-background hover:bg-primary/90 font-bold border border-primary">
                          {createEvidence.isPending ? "LOGGING..." : "COMMIT_ARTIFACT"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="space-y-3">
              {evidenceLoading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => <div key={i} className="h-16 bg-muted/20 animate-pulse border border-border"></div>)}
                </div>
              ) : evidence && evidence.length > 0 ? (
                evidence.map((item) => (
                  <div key={item.id} className="group bg-background border border-border p-3 relative hover:border-primary/30 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="mt-1 bg-card p-1 border border-border/50">{getEvidenceIcon(item.type)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="font-bold text-sm text-foreground truncate" title={item.label}>{item.label}</h4>
                          <span className="text-[10px] text-muted-foreground whitespace-nowrap">{format(new Date(item.createdAt), 'MM/dd/yy')}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="rounded-none uppercase text-[9px] py-0 px-1 border-border/50 text-muted-foreground">{item.type}</Badge>
                          {item.objectPath && (
                            <a
                              href={`/api/storage${item.objectPath}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[9px] text-primary flex items-center gap-1 hover:underline"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <Download className="w-2.5 h-2.5" />FILE
                            </a>
                          )}
                        </div>
                        {item.notes && (
                          <p className="mt-2 text-xs text-muted-foreground line-clamp-2" title={item.notes}>{item.notes}</p>
                        )}
                      </div>
                      <Button
                        variant="ghost" size="icon"
                        className="h-6 w-6 rounded-none text-muted-foreground opacity-0 group-hover:opacity-100 hover:text-destructive hover:bg-destructive/10 transition-all absolute top-2 right-2"
                        onClick={() => handleDeleteEvidence(item.id)}
                        disabled={deleteEvidenceMutation.isPending}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-sm text-muted-foreground border border-dashed border-border">NO_ARTIFACTS_LOGGED</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
