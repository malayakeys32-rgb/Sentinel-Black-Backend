import { useState } from "react";
import { Link } from "wouter";
import { format } from "date-fns";
import { useListCases } from "@workspace/api-client-react";
import { FolderKanban, Search, Filter, AlertTriangle } from "lucide-react";

import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function Cases() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  
  const { data: cases, isLoading } = useListCases(
    statusFilter !== "all" ? { status: statusFilter } : undefined
  );

  const filteredCases = cases?.filter(c => 
    searchQuery === "" || 
    c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (c.description && c.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
    String(c.id).includes(searchQuery)
  );

  const getPriorityColor = (priority: string | null | undefined) => {
    switch (priority) {
      case 'critical': return 'text-red-500 bg-red-500/10 border-red-500/20';
      case 'high': return 'text-orange-500 bg-orange-500/10 border-orange-500/20';
      case 'medium': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      case 'low': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      default: return 'text-muted-foreground bg-muted/10 border-muted/20';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'text-primary border-primary/50';
      case 'in-progress': return 'text-yellow-500 border-yellow-500/50';
      case 'closed': return 'text-white border-white/30';
      case 'archived': return 'text-muted-foreground border-muted-foreground/30';
      default: return 'text-muted-foreground border-muted-foreground/30';
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto font-mono">
      <div className="flex items-center justify-between mb-8 pb-4 border-b border-border">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
            <FolderKanban className="w-8 h-8 text-primary" />
            INTELLIGENCE_INDEX
          </h1>
          <p className="text-muted-foreground mt-1">Complete repository of all case files.</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search cases by ID, designation, or keyword..." 
            className="pl-10 bg-card rounded-none border-border focus-visible:ring-primary h-12"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="w-full sm:w-[200px]">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="bg-card rounded-none border-border focus:ring-primary h-12">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-muted-foreground" />
                <SelectValue placeholder="Filter Status" />
              </div>
            </SelectTrigger>
            <SelectContent className="bg-card border-border rounded-none">
              <SelectItem value="all">ALL_STATUSES</SelectItem>
              <SelectItem value="open">OPEN</SelectItem>
              <SelectItem value="in-progress">IN_PROGRESS</SelectItem>
              <SelectItem value="closed">CLOSED</SelectItem>
              <SelectItem value="archived">ARCHIVED</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="bg-card border border-border relative overflow-hidden">
        {isLoading ? (
          <div className="p-8 space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-12 bg-muted/20 animate-pulse border border-border/50"></div>
            ))}
          </div>
        ) : filteredCases && filteredCases.length > 0 ? (
          <Table>
            <TableHeader className="bg-muted/20 hover:bg-muted/20 border-b border-border">
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="w-[100px] text-muted-foreground font-bold font-mono">ID</TableHead>
                <TableHead className="text-muted-foreground font-bold">DESIGNATION</TableHead>
                <TableHead className="w-[150px] text-muted-foreground font-bold">STATUS</TableHead>
                <TableHead className="w-[150px] text-muted-foreground font-bold">PRIORITY</TableHead>
                <TableHead className="w-[200px] text-muted-foreground font-bold text-right">DATE_LOGGED</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCases.map((caseItem) => (
                <TableRow 
                  key={caseItem.id} 
                  className="border-border hover:bg-muted/10 cursor-pointer transition-colors group"
                >
                  <TableCell className="font-mono text-muted-foreground group-hover:text-primary transition-colors">
                    <Link href={`/cases/${caseItem.id}`} className="block">
                      {String(caseItem.id).padStart(4, '0')}
                    </Link>
                  </TableCell>
                  <TableCell className="font-bold text-foreground group-hover:text-primary transition-colors">
                    <Link href={`/cases/${caseItem.id}`} className="block">
                      {caseItem.title}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <Link href={`/cases/${caseItem.id}`} className="block">
                      <Badge variant="outline" className={`rounded-none uppercase font-bold text-[10px] ${getStatusColor(caseItem.status)}`}>
                        {caseItem.status}
                      </Badge>
                    </Link>
                  </TableCell>
                  <TableCell>
                    <Link href={`/cases/${caseItem.id}`} className="block">
                      <Badge variant="outline" className={`rounded-none uppercase font-bold text-[10px] border ${getPriorityColor(caseItem.priority)}`}>
                        {caseItem.priority || 'UNRATED'}
                      </Badge>
                    </Link>
                  </TableCell>
                  <TableCell className="text-right text-muted-foreground font-mono text-xs">
                    <Link href={`/cases/${caseItem.id}`} className="block">
                      {format(new Date(caseItem.createdAt), 'yyyy-MM-dd')}
                    </Link>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <div className="p-16 text-center flex flex-col items-center justify-center">
            <AlertTriangle className="w-12 h-12 text-muted-foreground mb-4 opacity-50" />
            <h3 className="text-lg font-bold text-foreground">NO_MATCHING_RECORDS</h3>
            <p className="text-muted-foreground max-w-md mt-2 text-sm">
              Adjust search parameters or status filters to locate specific files.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
