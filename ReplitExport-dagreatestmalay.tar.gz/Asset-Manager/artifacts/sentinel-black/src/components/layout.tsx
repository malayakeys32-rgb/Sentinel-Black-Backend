import { Link, useLocation } from "wouter";
import { useUser, useClerk } from "@clerk/react";
import { LayoutDashboard, FolderKanban, LogOut, Eye, CreditCard } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user } = useUser();
  const { signOut } = useClerk();

  const navigation = [
    { name: "Operations Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "Intelligence Index", href: "/cases", icon: FolderKanban },
    { name: "Billing & Access", href: "/billing", icon: CreditCard },
  ];

  return (
    <div className="flex min-h-screen bg-background text-foreground">
      {/* Sidebar */}
      <aside
        className="w-64 flex flex-col fixed inset-y-0 left-0 z-50"
        style={{
          background: '#080808',
          borderRight: '1px solid rgba(220,38,38,0.15)',
        }}
      >
        {/* Logo / Brand */}
        <div className="h-20 flex items-center px-5 gap-3"
          style={{ borderBottom: '1px solid rgba(220,38,38,0.12)' }}>
          <Link href="/" className="flex items-center gap-3 group">
            <img
              src="/sentinel-logo.png"
              alt="Sentinel Black"
              className="w-9 h-9 object-contain group-hover:drop-shadow-[0_0_8px_rgba(220,38,38,0.7)] transition-all"
            />
            <div className="flex flex-col leading-none">
              <span className="font-bold tracking-widest text-white text-xs">SENTINEL</span>
              <span className="font-bold tracking-widest text-primary text-xs" style={{ textShadow: '0 0 8px rgba(220,38,38,0.5)' }}>BLACK</span>
            </div>
          </Link>
        </div>

        {/* Thin red accent line */}
        <div className="h-px w-full" style={{ background: 'linear-gradient(90deg, transparent, rgba(220,38,38,0.5), transparent)' }} />

        <nav className="flex-1 px-3 py-6 space-y-1">
          {navigation.map((item) => {
            const isActive = location === item.href || (location.startsWith(item.href) && item.href !== "/");
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 text-xs font-bold tracking-widest transition-all uppercase ${
                  isActive
                    ? "text-white border-l-2 border-primary"
                    : "text-muted-foreground hover:text-white border-l-2 border-transparent"
                }`}
                style={isActive ? { background: 'rgba(220,38,38,0.08)', boxShadow: 'inset 0 0 20px rgba(220,38,38,0.05)' } : {}}
              >
                <item.icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-primary' : ''}`} />
                {item.name}
              </Link>
            );
          })}
        </nav>

        {/* User section */}
        <div className="p-4" style={{ borderTop: '1px solid rgba(220,38,38,0.12)' }}>
          <div className="flex items-center gap-3 mb-4 px-2">
            <div
              className="w-8 h-8 flex items-center justify-center font-bold text-xs overflow-hidden flex-shrink-0"
              style={{ border: '1px solid rgba(220,38,38,0.4)', background: 'rgba(220,38,38,0.1)' }}
            >
              {user?.imageUrl ? (
                <img src={user.imageUrl} alt={user.fullName || "User"} className="w-full h-full object-cover" />
              ) : (
                <Eye className="w-4 h-4 text-primary" />
              )}
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-bold truncate text-white tracking-wider">
                {user?.fullName || "OPERATIVE"}
              </span>
              <span className="text-[10px] text-muted-foreground truncate">
                {user?.primaryEmailAddress?.emailAddress}
              </span>
            </div>
          </div>
          <Button
            variant="ghost"
            className="w-full justify-start text-muted-foreground hover:text-primary hover:bg-primary/5 rounded-none border-l-2 border-transparent hover:border-primary px-3 py-2 h-auto text-xs tracking-widest uppercase font-bold"
            onClick={() => signOut({ redirectUrl: '/' })}
          >
            <LogOut className="w-3.5 h-3.5 mr-2" />
            Terminate Session
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 pl-64 min-h-screen" style={{ background: '#0a0a0a' }}>
        {children}
      </main>
    </div>
  );
}
