import { eq, sql } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";

export class StripeStorage {
  async getOrCreateUser(clerkUserId: string): Promise<typeof usersTable.$inferSelect> {
    const [existing] = await db.select().from(usersTable).where(eq(usersTable.clerkUserId, clerkUserId));
    if (existing) return existing;
    const [created] = await db.insert(usersTable).values({ clerkUserId }).returning();
    return created;
  }

  async updateUserStripeInfo(
    clerkUserId: string,
    data: { stripeCustomerId?: string; stripeSubscriptionId?: string },
  ) {
    const [updated] = await db
      .update(usersTable)
      .set(data)
      .where(eq(usersTable.clerkUserId, clerkUserId))
      .returning();
    return updated;
  }

  async listProductsWithPrices() {
    const result = await db.execute(sql`
      WITH paginated_products AS (
        SELECT id, name, description, metadata, active
        FROM stripe.products
        WHERE active = true
        ORDER BY name
      )
      SELECT
        p.id as product_id,
        p.name as product_name,
        p.description as product_description,
        p.active as product_active,
        p.metadata as product_metadata,
        pr.id as price_id,
        pr.unit_amount,
        pr.currency,
        pr.recurring,
        pr.active as price_active
      FROM paginated_products p
      LEFT JOIN stripe.prices pr ON pr.product = p.id AND pr.active = true
      ORDER BY p.name, pr.unit_amount
    `);
    return result.rows;
  }

  async getSubscription(subscriptionId: string) {
    const result = await db.execute(
      sql`SELECT * FROM stripe.subscriptions WHERE id = ${subscriptionId}`,
    );
    return result.rows[0] ?? null;
  }

  async getActiveSubscriptionForCustomer(customerId: string) {
    const result = await db.execute(
      sql`SELECT * FROM stripe.subscriptions WHERE customer = ${customerId} AND status IN ('active','trialing') LIMIT 1`,
    );
    return result.rows[0] ?? null;
  }
}

export const stripeStorage = new StripeStorage();
