import { Router, type IRouter, type Request, type Response } from "express";
import { requireAuth } from "./auth";
import { stripeStorage } from "../lib/stripeStorage";
import { getUncachableStripeClient } from "../lib/stripeClient";

const router: IRouter = Router();

const getAppBaseUrl = (req: Request) =>
  `${req.protocol}://${req.get("host")}`;

router.get("/billing/products", async (_req: Request, res: Response): Promise<void> => {
  try {
    const rows = await stripeStorage.listProductsWithPrices();
    const productsMap = new Map<string, { id: string; name: string; description: string | null; prices: object[] }>();

    for (const row of rows as any[]) {
      if (!productsMap.has(row.product_id)) {
        productsMap.set(row.product_id, {
          id: row.product_id,
          name: row.product_name,
          description: row.product_description,
          prices: [],
        });
      }
      if (row.price_id) {
        productsMap.get(row.product_id)!.prices.push({
          id: row.price_id,
          unitAmount: row.unit_amount,
          currency: row.currency,
          recurring: row.recurring,
        });
      }
    }

    res.json({ data: Array.from(productsMap.values()) });
  } catch (_err) {
    res.json({ data: [] });
  }
});

router.get("/billing/subscription", requireAuth, async (req: Request, res: Response): Promise<void> => {
  const userId = (req as any).userId as string;
  const user = await stripeStorage.getOrCreateUser(userId);

  if (!user.stripeCustomerId) {
    res.json({ subscription: null, plan: "free" });
    return;
  }

  try {
    const subscription = await stripeStorage.getActiveSubscriptionForCustomer(user.stripeCustomerId);
    res.json({ subscription, plan: subscription ? "pro" : "free" });
  } catch (_err) {
    res.json({ subscription: null, plan: "free" });
  }
});

router.post("/billing/checkout", requireAuth, async (req: Request, res: Response): Promise<void> => {
  const userId = (req as any).userId as string;
  const { priceId } = req.body;

  if (!priceId) {
    res.status(400).json({ error: "priceId is required" });
    return;
  }

  const user = await stripeStorage.getOrCreateUser(userId);
  const stripe = await getUncachableStripeClient();
  const baseUrl = getAppBaseUrl(req);

  let customerId = user.stripeCustomerId;
  if (!customerId) {
    const customer = await stripe.customers.create({ metadata: { clerkUserId: userId } });
    await stripeStorage.updateUserStripeInfo(userId, { stripeCustomerId: customer.id });
    customerId = customer.id;
  }

  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    payment_method_types: ["card"],
    line_items: [{ price: priceId, quantity: 1 }],
    mode: "subscription",
    success_url: `${baseUrl}/billing?session_id={CHECKOUT_SESSION_ID}&status=success`,
    cancel_url: `${baseUrl}/billing?status=cancelled`,
  });

  res.json({ url: session.url });
});

router.post("/billing/portal", requireAuth, async (req: Request, res: Response): Promise<void> => {
  const userId = (req as any).userId as string;
  const user = await stripeStorage.getOrCreateUser(userId);

  if (!user.stripeCustomerId) {
    res.status(400).json({ error: "No billing account found" });
    return;
  }

  const stripe = await getUncachableStripeClient();
  const baseUrl = getAppBaseUrl(req);

  const portal = await stripe.billingPortal.sessions.create({
    customer: user.stripeCustomerId,
    return_url: `${baseUrl}/billing`,
  });

  res.json({ url: portal.url });
});

export default router;
