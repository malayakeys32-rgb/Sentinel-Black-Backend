import { Router, type IRouter } from "express";
import { eq, and, desc } from "drizzle-orm";
import { db, casesTable, evidenceTable, summariesTable } from "@workspace/db";
import { requireAuth } from "./auth";
import { openai } from "@workspace/integrations-openai-ai-server";

const router: IRouter = Router();

router.get("/cases/:id/summaries", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const caseId = parseInt(rawId, 10);
  if (isNaN(caseId)) {
    res.status(400).json({ error: "Invalid case ID" });
    return;
  }

  const [c] = await db
    .select()
    .from(casesTable)
    .where(and(eq(casesTable.id, caseId), eq(casesTable.clerkUserId, userId)));

  if (!c) {
    res.status(404).json({ error: "Case not found" });
    return;
  }

  const items = await db
    .select()
    .from(summariesTable)
    .where(and(eq(summariesTable.caseId, caseId), eq(summariesTable.clerkUserId, userId)))
    .orderBy(desc(summariesTable.createdAt));

  res.json(items);
});

router.post("/cases/:id/summaries", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const rawId2 = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const caseId = parseInt(rawId2, 10);
  if (isNaN(caseId)) {
    res.status(400).json({ error: "Invalid case ID" });
    return;
  }

  const [c] = await db
    .select()
    .from(casesTable)
    .where(and(eq(casesTable.id, caseId), eq(casesTable.clerkUserId, userId)));

  if (!c) {
    res.status(404).json({ error: "Case not found" });
    return;
  }

  const evidence = await db
    .select()
    .from(evidenceTable)
    .where(and(eq(evidenceTable.caseId, caseId), eq(evidenceTable.clerkUserId, userId)))
    .orderBy(desc(evidenceTable.createdAt));

  const evidenceText = evidence.length > 0
    ? evidence.map((e, i) =>
        `${i + 1}. [${e.type.toUpperCase()}] ${e.label}${e.notes ? ` — ${e.notes}` : ""}`
      ).join("\n")
    : "No evidence logged yet.";

  const prompt = `You are a forensic intelligence analyst. Analyze the following case and its evidence, then produce a concise intelligence summary.

CASE: ${c.title}
STATUS: ${c.status}
PRIORITY: ${c.priority || "unrated"}
DESCRIPTION: ${c.description || "No description provided."}

EVIDENCE INVENTORY (${evidence.length} items):
${evidenceText}

Write a structured intelligence summary covering:
1. CASE OVERVIEW — what this case is about
2. EVIDENCE ASSESSMENT — key findings from the evidence inventory
3. THREAT LEVEL — assessment based on volume and types of evidence
4. RECOMMENDED ACTIONS — next investigative steps

Keep it concise, factual, and in the style of a classified intelligence brief.`;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 1024,
      messages: [{ role: "user" as const, content: prompt }],
    });

    const content = completion.choices[0]?.message?.content ?? "Unable to generate summary.";

    const [created] = await db
      .insert(summariesTable)
      .values({ caseId, content, clerkUserId: userId })
      .returning();

    res.status(201).json(created);
  } catch (err) {
    req.log.error({ err }, "AI summary generation failed");
    res.status(500).json({ error: "Failed to generate intelligence summary" });
  }
});

export default router;
