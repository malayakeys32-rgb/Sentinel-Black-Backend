import { Router, type IRouter } from "express";
import { eq, and, desc } from "drizzle-orm";
import { db, evidenceTable, casesTable } from "@workspace/db";
import {
  ListEvidenceParams,
  CreateEvidenceParams,
  CreateEvidenceBody,
  UpdateEvidenceParams,
  UpdateEvidenceBody,
  DeleteEvidenceParams,
  ListEvidenceResponse,
  UpdateEvidenceResponse,
} from "@workspace/api-zod";
import { requireAuth } from "./auth";

const router: IRouter = Router();

router.get("/cases/:id/evidence", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = ListEvidenceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  // Verify the case belongs to the user
  const [c] = await db
    .select()
    .from(casesTable)
    .where(and(eq(casesTable.id, params.data.id), eq(casesTable.clerkUserId, userId)));

  if (!c) {
    res.status(404).json({ error: "Case not found" });
    return;
  }

  const items = await db
    .select()
    .from(evidenceTable)
    .where(eq(evidenceTable.caseId, params.data.id))
    .orderBy(desc(evidenceTable.createdAt));

  res.json(ListEvidenceResponse.parse(items));
});

router.post("/cases/:id/evidence", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = CreateEvidenceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = CreateEvidenceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  // Verify the case belongs to the user
  const [c] = await db
    .select()
    .from(casesTable)
    .where(and(eq(casesTable.id, params.data.id), eq(casesTable.clerkUserId, userId)));

  if (!c) {
    res.status(404).json({ error: "Case not found" });
    return;
  }

  const [created] = await db
    .insert(evidenceTable)
    .values({ ...parsed.data, caseId: params.data.id, clerkUserId: userId })
    .returning();

  res.status(201).json(created);
});

router.patch("/evidence/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = UpdateEvidenceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateEvidenceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [updated] = await db
    .update(evidenceTable)
    .set(parsed.data)
    .where(and(eq(evidenceTable.id, params.data.id), eq(evidenceTable.clerkUserId, userId)))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Evidence not found" });
    return;
  }

  res.json(UpdateEvidenceResponse.parse(updated));
});

router.delete("/evidence/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = DeleteEvidenceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(evidenceTable)
    .where(and(eq(evidenceTable.id, params.data.id), eq(evidenceTable.clerkUserId, userId)))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Evidence not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
