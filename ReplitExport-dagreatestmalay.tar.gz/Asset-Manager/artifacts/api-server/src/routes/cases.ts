import { Router, type IRouter } from "express";
import { eq, and, desc } from "drizzle-orm";
import { db, casesTable } from "@workspace/db";
import {
  ListCasesQueryParams,
  CreateCaseBody,
  GetCaseParams,
  UpdateCaseParams,
  UpdateCaseBody,
  DeleteCaseParams,
  ListCasesResponse,
  GetCaseResponse,
  UpdateCaseResponse,
} from "@workspace/api-zod";
import { requireAuth } from "./auth";

const router: IRouter = Router();

router.get("/cases", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const query = ListCasesQueryParams.safeParse(req.query);

  let whereClause = eq(casesTable.clerkUserId, userId);

  const cases = await db
    .select()
    .from(casesTable)
    .where(
      query.success && query.data.status
        ? and(whereClause, eq(casesTable.status, query.data.status))
        : whereClause
    )
    .orderBy(desc(casesTable.updatedAt));

  res.json(ListCasesResponse.parse(cases));
});

router.post("/cases", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const parsed = CreateCaseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [created] = await db
    .insert(casesTable)
    .values({ ...parsed.data, clerkUserId: userId })
    .returning();

  res.status(201).json(GetCaseResponse.parse(created));
});

router.get("/cases/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = GetCaseParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [c] = await db
    .select()
    .from(casesTable)
    .where(and(eq(casesTable.id, params.data.id), eq(casesTable.clerkUserId, userId)));

  if (!c) {
    res.status(404).json({ error: "Case not found" });
    return;
  }

  res.json(GetCaseResponse.parse(c));
});

router.patch("/cases/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = UpdateCaseParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateCaseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [updated] = await db
    .update(casesTable)
    .set(parsed.data)
    .where(and(eq(casesTable.id, params.data.id), eq(casesTable.clerkUserId, userId)))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Case not found" });
    return;
  }

  res.json(UpdateCaseResponse.parse(updated));
});

router.delete("/cases/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const params = DeleteCaseParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(casesTable)
    .where(and(eq(casesTable.id, params.data.id), eq(casesTable.clerkUserId, userId)))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Case not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
