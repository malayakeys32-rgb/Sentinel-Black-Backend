import { Router, type IRouter } from "express";
import healthRouter from "./health";
import casesRouter from "./cases";
import evidenceRouter from "./evidence";
import dashboardRouter from "./dashboard";
import storageRouter from "./storage";
import summariesRouter from "./summaries";
import stripeRouter from "./stripe";

const router: IRouter = Router();

router.use(healthRouter);
router.use(casesRouter);
router.use(evidenceRouter);
router.use(dashboardRouter);
router.use(storageRouter);
router.use(summariesRouter);
router.use(stripeRouter);

export default router;
