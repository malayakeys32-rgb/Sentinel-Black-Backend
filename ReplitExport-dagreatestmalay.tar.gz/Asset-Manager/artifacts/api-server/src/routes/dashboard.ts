import { Router, type IRouter } from "express";
import { eq, desc, count } from "drizzle-orm";
import { db, casesTable, evidenceTable } from "@workspace/db";
import {
  GetDashboardStatsResponse,
  GetRecentCasesResponse,
} from "@workspace/api-zod";
import { requireAuth } from "./auth";

const router: IRouter = Router();

router.get("/dashboard/stats", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;

  const cases = await db
    .select()
    .from(casesTable)
    .where(eq(casesTable.clerkUserId, userId));

  const evidenceRows = await db
    .select({ count: count() })
    .from(evidenceTable)
    .where(eq(evidenceTable.clerkUserId, userId));

  const totalCases = cases.length;
  const openCases = cases.filter((c) => c.status === "open").length;
  const closedCases = cases.filter((c) => c.status === "closed").length;
  const totalEvidence = Number(evidenceRows[0]?.count ?? 0);

  const statusMap: Record<string, number> = {};
  for (const c of cases) {
    statusMap[c.status] = (statusMap[c.status] ?? 0) + 1;
  }
  const casesByStatus = Object.entries(statusMap).map(([status, count]) => ({ status, count }));

  res.json(
    GetDashboardStatsResponse.parse({
      totalCases,
      openCases,
      closedCases,
      totalEvidence,
      casesByStatus,
    })
  );
});

router.get("/dashboard/recent-cases", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;

  const cases = await db
    .select()
    .from(casesTable)
    .where(eq(casesTable.clerkUserId, userId))
    .orderBy(desc(casesTable.updatedAt))
    .limit(5);

  res.json(GetRecentCasesResponse.parse(cases));
});

export default router;
