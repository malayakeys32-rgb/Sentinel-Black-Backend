# Sentinel Black

A dark forensic intelligence console for investigators to track cases and index evidence.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/sentinel-black run dev` — run the frontend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required env: `CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY` — Clerk auth keys (auto-provisioned)
- Required env: `VITE_CLERK_PUBLISHABLE_KEY` — Clerk publishable key for frontend

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 + Clerk Express middleware
- Auth: Clerk (Replit-managed tenant)
- DB: PostgreSQL + Drizzle ORM
- Frontend: React + Vite + Tailwind v4 + shadcn/ui
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- DB schema: `lib/db/src/schema/` (cases.ts, evidence.ts)
- API contract: `lib/api-spec/openapi.yaml`
- Generated hooks: `lib/api-client-react/src/generated/`
- Generated Zod schemas: `lib/api-zod/src/generated/`
- API routes: `artifacts/api-server/src/routes/`
- Frontend: `artifacts/sentinel-black/src/`

## Architecture decisions

- Auth is handled by Replit-managed Clerk tenant — development uses pk_test keys, production uses live keys
- Clerk proxy middleware in Express routes Clerk SDK calls through the API server
- All cases and evidence are scoped to the authenticated clerkUserId
- OpenAPI-first: spec gates codegen, codegen gates frontend hooks
- requireAuth middleware extracts userId from Clerk session and attaches to req.userId

## Product

- Dark forensic console for case tracking and evidence management
- Email/password auth via Clerk
- Dashboard with live stats, recent cases
- Full case CRUD with status (open, in-progress, closed, archived) and priority
- Per-case evidence management (document, photo, audio, video, physical, digital, testimony)

## User preferences

- Dark forensic aesthetic: matte black backgrounds (#0a0a0a), crimson red accents (#dc2626), white text
- Logo: /public/sentinel-logo.png (Sentinel Black Corporation shield with eye)
- Red glow effects on key elements (drop-shadow, radial gradients)
- No emojis in UI
- Dense, information-rich layout
- Status colors: open=red/primary, in-progress=yellow, closed=white, archived=muted

## Gotchas

- Run codegen after every spec change: `pnpm --filter @workspace/api-spec run codegen`
- Run `pnpm --filter @workspace/db run push` after schema changes
- Clerk warning about pk_test keys in dev is expected — not an error
- After sign-out, redirect to / (home), not /sign-in
